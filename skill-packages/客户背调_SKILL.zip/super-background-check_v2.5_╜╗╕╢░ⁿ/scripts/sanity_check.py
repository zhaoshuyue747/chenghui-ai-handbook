# -*- coding: utf-8 -*-
"""
Super Background Check v2.5 - Sanity Check (17 hard assertions)

⛔ 反 Auto 偷懒律 #12 实现：
    任意一项 FAIL → sys.exit(1) + 红字"Auto 模型偷懒被拦截"
    通过则把 PASS 结果回写到 Sheet ⑤ 自检报告。

v2.5 新增 S14-S17 拦截贸易数据缺失：
    S14 Sheet ① 顶部存在『贸易体量速览』4 列卡片
    S15 Sheet ② 存在『第 10 维 · 进出口贸易数据』章节
    S16 分国家进口明细 ≥ 3 行 × 5 列齐全
    S17 年度总进口额 / 年度销售额 含 USD 前缀且非占位词

调用：
    python scripts/sanity_check.py --xlsx "D:/.../单客户档案_xxx_20260507.xlsx"
"""
import argparse
import os
import re
import sys

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        pass

try:
    from openpyxl import load_workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
except ImportError:
    print("[ERROR] openpyxl not installed.")
    sys.exit(1)


GREEN_FILL = PatternFill("solid", fgColor="C6EFCE")
RED_FILL = PatternFill("solid", fgColor="FFC7CE")
GREEN_FONT = Font(name="Microsoft YaHei", size=10, bold=True, color="006100")
RED_FONT = Font(name="Microsoft YaHei", size=10, bold=True, color="9C0006")

# Fallback / 占位词黑名单（命中即视为 AI 偷懒）
PLACEHOLDER_BLACKLIST = [
    "尊敬的客户，感谢您的咨询",
    "Dear customer, thank you for your inquiry",
    "待补充", "TBD", "N/A（默认）", "示例内容", "lorem ipsum",
    "示例话术", "占位文本",
]

# v2.5: 贸易数据字段不允许的占位词（S17 专用）
TRADE_PLACEHOLDER_BLACKLIST = [
    "暂未找到", "未公开", "未披露", "TBD", "N/A", "待补充", "示例", "0", "USD 0",
]


def fail(code, msg):
    print(f"[FAIL] {code} {msg}")
    print("=" * 60)
    print("❌ Auto 模型偷懒被拦截，请按 SKILL.md 重跑：")
    print("   1) python scripts/excel_gen.py --payload payload.json --out <文件名>")
    print("   2) python scripts/sanity_check.py --xlsx <文件名>")
    print("   严禁裸用 openpyxl 现场拼装 Excel！")
    sys.exit(1)


def check(xlsx_path):
    results = []  # list of (code, desc, status)

    # ---- S01 文件能正常打开 ----
    try:
        wb = load_workbook(xlsx_path)
    except Exception as e:
        fail("S01", f"openpyxl 无法打开文件 -> styles.xml 可能被裸 openpyxl 写坏: {e}")
    results.append(("S01", "文件能被 openpyxl 正常打开", "PASS"))

    # ---- S02 Sheet 数 = 5 ----
    sheet_names = wb.sheetnames
    if len(sheet_names) != 5:
        fail("S02", f"Sheet 数 != 5（实际 {len(sheet_names)}: {sheet_names}）")
    results.append(("S02", f"Sheet 数 = 5（{', '.join(sheet_names)}）", "PASS"))

    # 定位 4 个核心 Sheet（按出现顺序）
    s_summary = wb.worksheets[0]
    s_archive = wb.worksheets[1]
    s_contacts = wb.worksheets[2]
    s_sources = wb.worksheets[3]
    s_audit = wb.worksheets[4]

    # ---- S03 决策人图谱 ≥ 6 行 ----
    if s_contacts.max_row < 6:
        fail("S03", f"决策人图谱仅 {s_contacts.max_row} 行（要求 ≥ 6）")
    results.append(("S03", f"决策人图谱 = {s_contacts.max_row} 行", "PASS"))

    # ---- S04 决策人图谱列数 = 8 ----
    if s_contacts.max_column != 8:
        fail("S04", f"决策人图谱列数 = {s_contacts.max_column}（要求 = 8）")
    results.append(("S04", "决策人图谱 = 8 列", "PASS"))

    # ---- S05 至少 1 位 P0 ----
    has_p0 = False
    for row in s_contacts.iter_rows(min_row=3, max_col=8, values_only=True):
        if row and len(row) >= 8 and str(row[7]).strip() == "P0":
            has_p0 = True
            break
    if not has_p0:
        fail("S05", "决策人图谱中未发现任何 P0 优先级")
    results.append(("S05", "至少 1 位 P0 决策人", "PASS"))

    # ---- S06 数据来源 ≥ 4 行 ----
    if s_sources.max_row < 4:
        fail("S06", f"数据来源仅 {s_sources.max_row} 行（要求 ≥ 4）")
    results.append(("S06", f"数据来源 = {s_sources.max_row} 行", "PASS"))

    # ---- S07 风险评分单元格存在条件格式 ----
    has_cf = False
    for sheet in (s_summary, s_archive):
        if sheet.conditional_formatting and len(list(sheet.conditional_formatting)) > 0:
            has_cf = True
            break
    if not has_cf:
        fail("S07", "决策摘要 / 全息档案 均无条件格式规则（风险评分应有三色梯度）")
    results.append(("S07", "风险评分单元格存在条件格式规则", "PASS"))

    # ---- S08 决策结论单元格有填充色 ----
    found_decision_fill = False
    target_keywords = ("✅", "⚠", "❌", "决策", "推荐", "暂缓", "拒绝")
    for sheet in (s_summary, s_archive):
        for row in sheet.iter_rows(min_row=1, max_row=min(sheet.max_row, 60), max_col=4):
            for cell in row:
                v = str(cell.value or "")
                if any(k in v for k in target_keywords) and len(v) >= 2 and len(v) <= 80:
                    if cell.fill and cell.fill.patternType == "solid" and \
                       cell.fill.fgColor and cell.fill.fgColor.rgb and \
                       cell.fill.fgColor.rgb not in ("00000000",):
                        # 排除章节绿条（通常是 GREEN 00B050 / NAVY 1F4E79 大色块作为标题）
                        rgb_hex = str(cell.fill.fgColor.rgb).upper()
                        if rgb_hex.endswith("C6EFCE") or rgb_hex.endswith("FFEB9C") or rgb_hex.endswith("FFC7CE"):
                            found_decision_fill = True
                            break
            if found_decision_fill:
                break
        if found_decision_fill:
            break
    if not found_decision_fill:
        fail("S08", "未找到决策结论单元格的语义填充色（绿/黄/红）")
    results.append(("S08", "决策结论有语义填充色", "PASS"))

    # ---- S09 文件名格式 ----
    fname = os.path.basename(xlsx_path)
    if not re.fullmatch(r"单客户档案_[A-Za-z0-9_\-]+_\d{8}\.xlsx", fname):
        fail("S09", f"文件名 '{fname}' 不符合 '单客户档案_{{company_short}}_{{YYYYMMDD}}.xlsx' 格式")
    results.append(("S09", f"文件名格式合法（{fname}）", "PASS"))

    # ---- S10 文件大小 > 10KB ----
    fsize = os.path.getsize(xlsx_path)
    if fsize < 10 * 1024:
        fail("S10", f"文件大小仅 {fsize} bytes（要求 > 10KB），疑似空壳")
    results.append(("S10", f"文件大小 = {fsize/1024:.1f} KB", "PASS"))

    # ---- S11 全息档案 ≥ 39 行（v2.5: 含第 10 维进出口贸易章节）----
    if s_archive.max_row < 39:
        fail("S11", f"全息档案仅 {s_archive.max_row} 行（要求 ≥ 39，必须含第 10 维进出口贸易章节）")
    results.append(("S11", f"全息档案 = {s_archive.max_row} 行", "PASS"))

    # ---- S12 5 套话术每套 ≥ 20 字 ----
    pitch_texts = []
    capture = False
    for row in s_summary.iter_rows(min_row=1, max_row=s_summary.max_row, max_col=4, values_only=True):
        if not row:
            continue
        joined = " | ".join(str(c) for c in row if c)
        if "差异化切入话术" in joined:
            capture = True
            continue
        if capture:
            if "中文开发信" in joined or "English Development" in joined:
                break
            # 行首单元格匹配 "切入 N"
            first = str(row[0]) if row[0] is not None else ""
            if first.startswith("切入"):
                pitch = ""
                for c in row[1:]:
                    if c:
                        pitch += str(c)
                pitch_texts.append(pitch.strip())
    if len(pitch_texts) < 5:
        fail("S12", f"未找到完整 5 套话术（实际 {len(pitch_texts)} 套）")
    short_idx = [i + 1 for i, p in enumerate(pitch_texts[:5]) if len(p) < 20]
    if short_idx:
        fail("S12", f"话术 {short_idx} 字数 < 20（疑似占位）")
    for i, p in enumerate(pitch_texts[:5], 1):
        for bw in PLACEHOLDER_BLACKLIST:
            if bw.lower() in p.lower():
                fail("S12", f"话术 {i} 命中占位词黑名单 '{bw}'")
    results.append(("S12", f"5 套话术全部 ≥ 20 字 (avg {sum(len(p) for p in pitch_texts[:5])//5})", "PASS"))

    # ---- S13 中英开发信各 ≥ 50 字 + 黑名单 ----
    cn_email, en_email = "", ""
    state = None  # "cn" | "en"
    for row in s_summary.iter_rows(min_row=1, max_row=s_summary.max_row, max_col=4, values_only=True):
        if not row:
            continue
        joined = " | ".join(str(c) for c in row if c)
        if "中文开发信" in joined:
            state = "cn"
            continue
        if "English Development" in joined or "英文开发信" in joined:
            state = "en"
            continue
        if state == "cn" and row[0] and "English Development" not in joined:
            cn_email += str(row[0])
        if state == "en" and row[0]:
            en_email += str(row[0])
    if len(cn_email.strip()) < 50:
        fail("S13", f"中文开发信仅 {len(cn_email.strip())} 字（要求 ≥ 50）")
    if len(en_email.strip()) < 50:
        fail("S13", f"English email only {len(en_email.strip())} chars (need ≥ 50)")
    for bw in PLACEHOLDER_BLACKLIST:
        if bw.lower() in cn_email.lower() or bw.lower() in en_email.lower():
            fail("S13", f"开发信命中占位词黑名单 '{bw}'")
    results.append(("S13", f"中文 {len(cn_email.strip())} 字 + English {len(en_email.strip())} chars，无占位", "PASS"))

    # ============ v2.5 新增：S14-S17 ============

    # ---- S14 Sheet ① 顶部贸易体量速览 4 列卡片 ----
    found_trade_card = False
    for row in s_summary.iter_rows(min_row=1, max_row=10, max_col=4, values_only=True):
        if not row:
            continue
        joined = " | ".join(str(c) for c in row if c)
        if "贸易体量速览" in joined or ("年度总进口额" in joined and "年度销售额" in joined):
            found_trade_card = True
            break
    if not found_trade_card:
        fail("S14", "Sheet ① 顶部 10 行内未找到『贸易体量速览』4 列卡片（v2.5 必须）")
    # 二次校验：必须有 4 个表头单元格
    headers_required = ["年度总进口额", "年度销售额", "进口占销比", "数据年份"]
    header_row_found = False
    for row in s_summary.iter_rows(min_row=1, max_row=10, max_col=4, values_only=True):
        if not row:
            continue
        cells = [str(c).strip() if c else "" for c in row]
        if all(any(h in c for c in cells) for h in headers_required):
            header_row_found = True
            break
    if not header_row_found:
        fail("S14", f"Sheet ① 速览卡片表头缺失，需包含 4 个表头：{headers_required}")
    results.append(("S14", "Sheet ① 贸易体量速览 4 列卡片 OK", "PASS"))

    # ---- S15 Sheet ② 第 10 维章节标题条 ----
    found_dim10_section = False
    for row in s_archive.iter_rows(min_row=1, max_row=s_archive.max_row, max_col=5, values_only=True):
        if not row:
            continue
        joined = " | ".join(str(c) for c in row if c)
        if "进出口贸易数据" in joined and ("10" in joined or "第 10 维" in joined or "v2.5" in joined):
            found_dim10_section = True
            break
    if not found_dim10_section:
        fail("S15", "Sheet ② 全息档案未找到『第 10 维 · 进出口贸易数据』章节标题条（v2.5 必须）")
    results.append(("S15", "Sheet ② 第 10 维进出口贸易章节 OK", "PASS"))

    # ---- S16 分国家进口明细 ≥ 3 行 × 5 列齐全 ----
    breakdown_header_row = None
    breakdown_headers = ["国家", "进口金额", "占比", "主要品类", "Top 供应商"]
    for r_idx, row in enumerate(s_archive.iter_rows(min_row=1, max_row=s_archive.max_row, max_col=5, values_only=True), start=1):
        if not row:
            continue
        cells = [str(c).strip() if c else "" for c in row]
        # 找到包含 4 个以上表头关键词的行
        hit = sum(1 for h in breakdown_headers if any(h in c for c in cells))
        if hit >= 4:
            breakdown_header_row = r_idx
            break
    if not breakdown_header_row:
        fail("S16", f"Sheet ② 未找到分国家进口明细表头行（需含 {breakdown_headers} 中的 ≥4 个）")
    # 数据行：从表头下一行开始连续读，直到遇到空行
    data_rows = []
    for r_idx in range(breakdown_header_row + 1, s_archive.max_row + 1):
        row_vals = [s_archive.cell(row=r_idx, column=c).value for c in range(1, 6)]
        # 必须 5 列齐全（每列非空）
        if all(v is not None and str(v).strip() != "" for v in row_vals):
            data_rows.append(row_vals)
        else:
            break
    if len(data_rows) < 3:
        fail("S16", f"分国家进口明细仅 {len(data_rows)} 行（要求 ≥ 3，且每行 5 列齐全）")
    # 检查每行金额列是否含 USD
    for i, drow in enumerate(data_rows[:3], 1):
        amount_str = str(drow[1])
        if "USD" not in amount_str.upper() and "$" not in amount_str:
            fail("S16", f"分国家明细第 {i} 行 '金额' 列 '{amount_str}' 缺少 USD/$ 前缀")
    results.append(("S16", f"分国家进口明细 = {len(data_rows)} 行 × 5 列齐全", "PASS"))

    # ---- S17 年度总进口额 / 销售额 含 USD 前缀 + 非占位词 ----
    # 在 Sheet ① 速览卡片数据行查找（已知卡片在第 4-5 行附近）
    trade_total_import = None
    trade_total_revenue = None
    for r_idx in range(1, 11):
        for c_idx in range(1, 5):
            v = s_summary.cell(row=r_idx, column=c_idx).value
            if v is None:
                continue
            v_str = str(v).strip()
            if v_str in ("年度总进口额",):
                # 同行下一列 / 下一行同列
                trade_total_import = s_summary.cell(row=r_idx + 1, column=c_idx).value
            if v_str in ("年度销售额",):
                trade_total_revenue = s_summary.cell(row=r_idx + 1, column=c_idx).value

    if not trade_total_import:
        fail("S17", "Sheet ① 速览卡片未找到『年度总进口额』数值")
    if not trade_total_revenue:
        fail("S17", "Sheet ① 速览卡片未找到『年度销售额』数值")
    for label, val in [("年度总进口额", trade_total_import), ("年度销售额", trade_total_revenue)]:
        v_str = str(val).strip()
        if "USD" not in v_str.upper() and "$" not in v_str:
            fail("S17", f"『{label}』= '{v_str}' 缺少 USD/$ 前缀")
        for bw in TRADE_PLACEHOLDER_BLACKLIST:
            if v_str.lower() == bw.lower() or v_str.lower().startswith(bw.lower() + " "):
                fail("S17", f"『{label}』命中占位词黑名单 '{bw}'，禁止用占位")
    results.append(("S17", f"贸易关键金额含 USD 前缀且非占位（{trade_total_import} / {trade_total_revenue}）", "PASS"))

    # ---- 全部通过 -> 回写 Sheet ⑤ ----
    write_back_audit(s_audit, results)
    wb.save(xlsx_path)

    print("=" * 60)
    print(f"✅ ALL {len(results)} CHECKS PASSED ({len(results)}/17)")
    print(f"📊 文件: {xlsx_path}")
    print(f"📊 大小: {fsize/1024:.1f} KB")
    print(f"📊 Sheets: {sheet_names}")
    print("=" * 60)
    return 0


def write_back_audit(ws, results):
    # 找到每行 S01-S13 写入第 3 列
    code_to_status = {code: (status, desc) for code, desc, status in results}
    for r in range(3, ws.max_row + 1):
        code_cell = ws.cell(row=r, column=1).value
        if not code_cell:
            continue
        code = str(code_cell).strip()
        if code in code_to_status:
            status, desc = code_to_status[code]
            c = ws.cell(row=r, column=3, value=f"✅ {status}")
            c.font = GREEN_FONT
            c.fill = GREEN_FILL
            c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
            thin = Side(border_style="thin", color="BFBFBF")
            c.border = Border(left=thin, right=thin, top=thin, bottom=thin)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--xlsx", required=True)
    args = ap.parse_args()

    if not os.path.exists(args.xlsx):
        print(f"[ERROR] 文件不存在: {args.xlsx}")
        sys.exit(1)

    sys.exit(check(args.xlsx))


if __name__ == "__main__":
    main()
