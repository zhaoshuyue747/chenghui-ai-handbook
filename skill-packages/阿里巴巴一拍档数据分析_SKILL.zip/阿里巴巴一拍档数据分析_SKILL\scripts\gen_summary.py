import sys
sys.path.insert(0, r'C:\Users\zhaos\.accio\accounts\1747555973_470001\skills\xlsx\scripts')

import pandas as pd
import numpy as np
import warnings
warnings.filterwarnings('ignore')

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from builders import build_table, build_chart
from style_kit import highlight_cells, add_data_bars, add_color_scale, add_icon_set

BASE = r'C:\Users\zhaos\Desktop\猪猪の文件\数据库'
OUT  = r'C:\Users\zhaos\.accio\accounts\1747555973_470001\agents\DID-F456DA-15F456DAU1781073-7441-58F963\project\拍档业务汇总分析.xlsx'

# ============================================================
# 读取各数据源（取6月最新数据）
# ============================================================

# 1. 信保GMV - 销售维度（取6月月度 + 季度 + 年度）
gmv_raw = pd.read_excel(f'{BASE}/信保GMV.xlsx', sheet_name='销售数据', header=1)
gmv_raw.columns = ['销售','销售主管','拍档','拍档id','生态主管','大区','月份',
                   '信保月度实收','信保月度同比','信保季度实收','信保季度同比','信保年度实收','信保年度同比']
gmv = gmv_raw[gmv_raw['月份'] == pd.Timestamp('2026-06-01')].copy()
gmv = gmv[gmv['销售'] != '-'].reset_index(drop=True)
gmv = gmv[['销售','销售主管','信保月度实收','信保月度同比','信保季度实收','信保季度同比','信保年度实收','信保年度同比']]

# 2. ACP收入 - 销售维度（取6月）
acp_raw = pd.read_excel(f'{BASE}/ACP收入.xlsx', sheet_name='销售数据', header=1)
acp_raw.columns = ['销售','销售主管','拍档','拍档id','生态主管','大区','月份',
                   'ACP月度实收','ACP月度同比','ACP月度目标','ACP月度完成率',
                   'ACP季度实收','ACP季度同比','ACP季度目标','ACP季度完成率',
                   'ACP年度实收','ACP年度同比']
acp = acp_raw[acp_raw['月份'] == pd.Timestamp('2026-06-01')].copy()
acp = acp[acp['销售'] != '-'].reset_index(drop=True)
acp = acp[['销售','ACP月度实收','ACP月度目标','ACP月度完成率',
           'ACP季度实收','ACP季度目标','ACP季度完成率','ACP年度实收']]

# 3. 3万客户数
kh = pd.read_excel(f'{BASE}/3万客户数.xlsx', sheet_name='销售数据')
kh = kh[kh['拍档销售'] != '-'].reset_index(drop=True)
kh = kh[['拍档销售','本季度3w客户数计数','同比季度3w客户数计数']].rename(
    columns={'拍档销售':'销售','本季度3w客户数计数':'3W客户数','同比季度3w客户数计数':'同比3W客户数'})

# 4. 优爆品
yb = pd.read_excel(f'{BASE}/优爆品数据.xlsx', sheet_name='销售数据')
yb = yb[['拍档销售','服务中客户数','当前有优爆品的客户数','当前优爆品数',
          '优爆品比例','当季度累计目标','当季度累计目标达成率',
          'p4p推广中优爆品数','优爆品p4p推广中比例']].rename(
    columns={'拍档销售':'销售','当季度累计目标达成率':'优爆品目标达成率','当季度累计目标':'优爆品季度目标'})

# ============================================================
# 合并成一张汇总表
# ============================================================
df = gmv.merge(acp, on='销售', how='left') \
        .merge(kh, on='销售', how='left') \
        .merge(yb, on='销售', how='left')

# 派生指标
df['ACP/信保渗透率'] = df['ACP月度实收'] / df['信保月度实收']
df['信保客单价（元/3W客）'] = df['信保季度实收'] / df['3W客户数']
df['爆品/客户覆盖比'] = df['当前优爆品数'] / df['服务中客户数']

# 排名列
df['信保季度排名'] = df['信保季度实收'].rank(ascending=False, method='min').astype(int)
df['ACP季度排名']  = df['ACP季度实收'].rank(ascending=False, method='min').astype(int)
df['3W客户排名']   = df['3W客户数'].rank(ascending=False, method='min').astype(int)
df['优爆品排名']   = df['当前优爆品数'].rank(ascending=False, method='min').astype(int)

# 整理列顺序
cols = [
    '销售','销售主管',
    # 信保
    '信保月度实收','信保月度同比','信保季度实收','信保季度同比','信保年度实收','信保季度排名',
    # ACP
    'ACP月度实收','ACP月度目标','ACP月度完成率','ACP季度实收','ACP季度目标','ACP季度完成率','ACP年度实收','ACP季度排名',
    # 3W客户
    '3W客户数','同比3W客户数','3W客户排名',
    # 优爆品
    '服务中客户数','当前有优爆品的客户数','当前优爆品数','优爆品比例','优爆品季度目标','优爆品目标达成率',
    'p4p推广中优爆品数','优爆品p4p推广中比例','优爆品排名',
    # 派生
    'ACP/信保渗透率','信保客单价（元/3W客）','爆品/客户覆盖比',
]
df = df[cols]

print("汇总表行数:", len(df))
print(df[['销售','信保季度实收','信保季度排名','ACP季度实收','ACP季度排名','3W客户数','3W客户排名','当前优爆品数','优爆品排名']].to_string())

# ============================================================
# 生成Excel
# ============================================================
wb = Workbook()
wb._named_styles['Normal'].font = Font(name='Microsoft YaHei', size=10)

# ---- Sheet 1: 汇总总览（仅核心列，可读性强）----
ws1 = wb.active
ws1.title = '销售汇总总览'
ws1.sheet_view.showGridLines = False

df_view = df[['销售','销售主管',
              '信保月度实收','信保季度实收','信保季度同比','信保季度排名',
              'ACP月度实收','ACP季度实收','ACP季度完成率','ACP季度排名',
              '3W客户数','同比3W客户数','3W客户排名',
              '当前优爆品数','优爆品目标达成率','优爆品排名',
              'ACP/信保渗透率','信保客单价（元/3W客）','爆品/客户覆盖比']].copy()

# 同比转百分比显示
for col in ['信保季度同比','ACP/信保渗透率','优爆品目标达成率']:
    df_view[col] = df_view[col]

t1 = build_table(
    ws1, data=df_view, anchor='B2',
    title='拍档团队销售综合业绩汇总 — FY27Q1（截至2026-06-27）',
    theme='modern_finance',
    column_formats={
        '信保月度实收':'simple_int','信保季度实收':'simple_int','信保季度同比':'pct_1',
        'ACP月度实收':'simple_int','ACP季度实收':'simple_int','ACP季度完成率':'pct_1',
        '3W客户数':'simple_int','同比3W客户数':'simple_int',
        '当前优爆品数':'simple_int','优爆品目标达成率':'pct_1',
        'ACP/信保渗透率':'pct_2','信保客单价（元/3W客）':'simple_int','爆品/客户覆盖比':'dec_1',
    },
    auto_width=True, band_rows=True,
)
# 排名越小越好：1=绿，后几名=红
highlight_cells(ws1, t1, rules=[
    {'column':'信保季度排名','when':'le','value':3,'style':'green_fill'},
    {'column':'信保季度排名','when':'ge','value':7,'style':'red_fill'},
    {'column':'ACP季度排名','when':'le','value':3,'style':'green_fill'},
    {'column':'ACP季度排名','when':'ge','value':7,'style':'red_fill'},
    {'column':'3W客户排名','when':'le','value':3,'style':'green_fill'},
    {'column':'3W客户排名','when':'ge','value':7,'style':'red_fill'},
    {'column':'优爆品排名','when':'le','value':3,'style':'green_fill'},
    {'column':'优爆品排名','when':'ge','value':7,'style':'red_fill'},
    {'column':'ACP季度完成率','when':'ge','value':1.0,'style':'green_fill'},
    {'column':'ACP季度完成率','when':'lt','value':0.7,'style':'red_fill'},
    {'column':'优爆品目标达成率','when':'ge','value':1.0,'style':'green_fill'},
    {'column':'优爆品目标达成率','when':'lt','value':0.8,'style':'amber_fill'},
])
add_data_bars(ws1, t1, columns=['信保季度实收'], color='sky')
add_data_bars(ws1, t1, columns=['ACP季度实收'], color='peach')
add_data_bars(ws1, t1, columns=['3W客户数'], color='mint')
add_data_bars(ws1, t1, columns=['当前优爆品数'], color='lavender')

# ---- Sheet 2: 信保GMV明细 ----
ws2 = wb.create_sheet('信保GMV明细')
ws2.sheet_view.showGridLines = False

df_gmv = df[['销售','销售主管','信保月度实收','信保月度同比',
             '信保季度实收','信保季度同比','信保年度实收','信保季度排名']].sort_values('信保季度实收', ascending=False)
t2 = build_table(ws2, data=df_gmv, anchor='B2',
    title='信保GMV明细 — FY27Q1（佣金口径·贴网总实收）',
    theme='modern_finance',
    column_formats={'信保月度实收':'simple_int','信保季度实收':'simple_int','信保年度实收':'simple_int',
                    '信保月度同比':'pct_1','信保季度同比':'pct_1'},
    total_row=True, auto_width=True, band_rows=True)
highlight_cells(ws2, t2, rules=[
    {'column':'信保季度同比','when':'gt','value':0,'style':'green_text'},
    {'column':'信保季度同比','when':'lt','value':0,'style':'red_text'},
])
add_data_bars(ws2, t2, columns=['信保季度实收'], color='sky')
build_chart(ws2, kind='clustered_bar',
    data_range=f"'信保GMV明细'!B{t2['header_row']}:D{t2['data_rows'][1]}",
    series_orient='cols', title='信保月度 vs 季度实收对比（元）',
    anchor='J2', size=(600,320), theme='modern_finance',
    legend='bottom', gridlines='horizontal_dashed', y_axis_min='zero', y_number_format='int')

# ---- Sheet 3: ACP收入明细 ----
ws3 = wb.create_sheet('ACP收入明细')
ws3.sheet_view.showGridLines = False

df_acp = df[['销售','销售主管','ACP月度实收','ACP月度目标','ACP月度完成率',
             'ACP季度实收','ACP季度目标','ACP季度完成率','ACP年度实收','ACP季度排名',
             'ACP/信保渗透率']].sort_values('ACP季度实收', ascending=False)
t3 = build_table(ws3, data=df_acp, anchor='B2',
    title='ACP收入明细 — FY27Q1（ACP全量实收）',
    theme='modern_finance',
    column_formats={'ACP月度实收':'simple_int','ACP月度目标':'simple_int','ACP月度完成率':'pct_1',
                    'ACP季度实收':'simple_int','ACP季度目标':'simple_int','ACP季度完成率':'pct_1',
                    'ACP年度实收':'simple_int','ACP/信保渗透率':'pct_2'},
    total_row=True, auto_width=True, band_rows=True)
highlight_cells(ws3, t3, rules=[
    {'column':'ACP季度完成率','when':'ge','value':1.0,'style':'green_fill'},
    {'column':'ACP季度完成率','when':'lt','value':0.7,'style':'red_fill'},
    {'column':'ACP/信保渗透率','when':'ge','value':0.1,'style':'green_text'},
    {'column':'ACP/信保渗透率','when':'lt','value':0.05,'style':'red_text'},
])
add_data_bars(ws3, t3, columns=['ACP季度实收'], color='peach')
build_chart(ws3, kind='combo_bar_line',
    data_range=f"'ACP收入明细'!B{t3['header_row']}:H{t3['data_rows'][1]}",
    series_orient='cols', title='ACP季度实收 vs 目标完成率',
    anchor='M2', size=(600,320), theme='modern_finance',
    legend='bottom', gridlines='horizontal_dashed', y_axis_min='zero',
    combo_line_series=[-1])

# ---- Sheet 4: 3W客户数明细 ----
ws4 = wb.create_sheet('3W客户数明细')
ws4.sheet_view.showGridLines = False

df_kh = df[['销售','销售主管','3W客户数','同比3W客户数','3W客户排名',
            '服务中客户数']].sort_values('3W客户数', ascending=False).copy()
df_kh['3W客户同比增减'] = df_kh['3W客户数'] - df_kh['同比3W客户数']
df_kh['3W渗透率（3W/服务）'] = df_kh['3W客户数'] / df_kh['服务中客户数']
t4 = build_table(ws4, data=df_kh, anchor='B2',
    title='3万活跃客户数明细 — FY27Q1',
    theme='modern_finance',
    column_formats={'3W客户数':'simple_int','同比3W客户数':'simple_int',
                    '3W客户同比增减':'simple_int','服务中客户数':'simple_int',
                    '3W渗透率（3W/服务）':'pct_1'},
    auto_width=True, band_rows=True)
highlight_cells(ws4, t4, rules=[
    {'column':'3W客户同比增减','when':'gt','value':0,'style':'green_text'},
    {'column':'3W客户同比增减','when':'lt','value':0,'style':'red_text'},
    {'column':'3W客户排名','when':'le','value':3,'style':'green_fill'},
])
add_data_bars(ws4, t4, columns=['3W客户数'], color='mint')
add_data_bars(ws4, t4, columns=['3W渗透率（3W/服务）'], color='sky')
build_chart(ws4, kind='clustered_bar',
    data_range=f"'3W客户数明细'!B{t4['header_row']}:D{t4['data_rows'][1]}",
    series_orient='cols', title='3W活跃客户数：本季 vs 同比',
    anchor='I2', size=(560,300), theme='modern_finance',
    legend='bottom', gridlines='horizontal_dashed', y_axis_min='zero', y_number_format='int')

# ---- Sheet 5: 优爆品明细 ----
ws5 = wb.create_sheet('优爆品明细')
ws5.sheet_view.showGridLines = False

df_yb = df[['销售','销售主管','服务中客户数','当前有优爆品的客户数','当前优爆品数',
            '优爆品比例','优爆品季度目标','优爆品目标达成率',
            'p4p推广中优爆品数','优爆品p4p推广中比例','爆品/客户覆盖比','优爆品排名']].sort_values('当前优爆品数', ascending=False)
t5 = build_table(ws5, data=df_yb, anchor='B2',
    title='优爆品3.0明细 — FY27Q1（截至2026-06-27）',
    theme='modern_finance',
    column_formats={'服务中客户数':'simple_int','当前有优爆品的客户数':'simple_int',
                    '当前优爆品数':'simple_int','优爆品比例':'pct_1',
                    '优爆品季度目标':'simple_int','优爆品目标达成率':'pct_1',
                    'p4p推广中优爆品数':'simple_int','优爆品p4p推广中比例':'pct_1',
                    '爆品/客户覆盖比':'dec_1'},
    auto_width=True, band_rows=True)
highlight_cells(ws5, t5, rules=[
    {'column':'优爆品目标达成率','when':'ge','value':1.0,'style':'green_fill'},
    {'column':'优爆品目标达成率','when':'lt','value':0.85,'style':'amber_fill'},
    {'column':'优爆品排名','when':'le','value':3,'style':'green_fill'},
])
add_data_bars(ws5, t5, columns=['当前优爆品数'], color='lavender')
add_color_scale(ws5, t5, columns=['优爆品目标达成率'], scale='white_blue')
build_chart(ws5, kind='clustered_bar',
    data_range=f"'优爆品明细'!B{t5['header_row']}:D{t5['data_rows'][1]}",
    series_orient='cols', title='当前优爆品数',
    anchor='N2', size=(560,300), theme='modern_finance',
    legend='bottom', gridlines='horizontal_dashed', y_axis_min='zero', y_number_format='int')

# ---- Sheet 6: 赵舒越个人业绩 ----
ws6 = wb.create_sheet('赵舒越个人业绩')
ws6.sheet_view.showGridLines = False

zsy = df[df['销售'] == '赵舒越'].iloc[0]

# 构建个人指标表
personal_data = [
    ['信保月度实收（6月）',     zsy['信保月度实收'],     '元', f"同比 {zsy['信保月度同比']:.1%}", f"团队排名 #{int(df['信保月度实收'].rank(ascending=False)[df['销售']=='赵舒越'].values[0])}"],
    ['信保季度实收（FY27Q1）',  zsy['信保季度实收'],     '元', f"同比 {zsy['信保季度同比']:.1%}", f"团队排名 #{zsy['信保季度排名']}"],
    ['信保年度实收（FY27YTD）', zsy['信保年度实收'],     '元', '—', '—'],
    ['ACP月度实收（6月）',      zsy['ACP月度实收'],      '元', f"目标完成 {zsy['ACP月度完成率']:.1%}", f"月度目标 {int(zsy['ACP月度目标']):,}"],
    ['ACP季度实收（FY27Q1）',   zsy['ACP季度实收'],      '元', f"目标完成 {zsy['ACP季度完成率']:.1%}", f"团队排名 #{zsy['ACP季度排名']}"],
    ['3W活跃客户数（FY27Q1）',  zsy['3W客户数'],         '家', f"同比 {int(zsy['3W客户数']-zsy['同比3W客户数']):+d} 家", f"团队排名 #{zsy['3W客户排名']}"],
    ['当前优爆品数',             zsy['当前优爆品数'],      '个', f"季度目标达成 {zsy['优爆品目标达成率']:.1%}", f"团队排名 #{zsy['优爆品排名']}"],
    ['ACP/信保渗透率',           round(zsy['ACP/信保渗透率']*100,2), '%', '越高越好，团队均值'+f"{df['ACP/信保渗透率'].mean()*100:.1f}%", '—'],
    ['信保客单价（元/3W客）',    int(zsy['信保客单价（元/3W客）']), '元/家', '信保季度实收÷3W客户数', '—'],
    ['爆品/客户覆盖比',          round(zsy['爆品/客户覆盖比'],1), '个/家', '优爆品数÷服务客户数', '—'],
]
df_personal = pd.DataFrame(personal_data, columns=['指标','数值','单位','备注','排名/目标'])
t6 = build_table(ws6, data=df_personal, anchor='B2',
    title='赵舒越 个人业绩卡 — FY27Q1（截至2026-06-27）',
    theme='executive_report',
    column_formats={'数值':'simple_dec_2'},
    auto_width=True, band_rows=True)
highlight_cells(ws6, t6, rules=[
    {'column':'排名/目标','when':'eq','value':'团队排名 #1','style':'green_fill'},
    {'column':'排名/目标','when':'eq','value':'团队排名 #2','style':'green_fill'},
    {'column':'排名/目标','when':'eq','value':'团队排名 #3','style':'green_fill'},
])

# ---- Sheet 7: 数据分析洞察 ----
ws7 = wb.create_sheet('数据分析洞察')
ws7.sheet_view.showGridLines = False

# 团队均值和排名分析
gmv_q_mean = df['信保季度实收'].mean()
acp_q_mean = df['ACP季度实收'].mean()
kh_mean    = df['3W客户数'].mean()
yb_mean    = df['当前优爆品数'].mean()
acp_pct_mean = df['ACP/信保渗透率'].mean()
yb_rate_mean = df['优爆品目标达成率'].mean()

analysis_rows = [
    ['TOP表现者（信保季度）', df.loc[df['信保季度实收'].idxmax(),'销售'],
     f"{int(df['信保季度实收'].max()):,}元",
     f"是团队均值的{df['信保季度实收'].max()/gmv_q_mean:.1f}倍",
     '绝对领先，重点保持'],
    ['TOP表现者（ACP季度）', df.loc[df['ACP季度实收'].idxmax(),'销售'],
     f"{int(df['ACP季度实收'].max()):,}元",
     f"ACP达成率{df.loc[df['ACP季度实收'].idxmax(),'ACP季度完成率']:.1%}",
     'ACP标杆，提炼方法论'],
    ['TOP表现者（3W客户）', df.loc[df['3W客户数'].idxmax(),'销售'],
     f"{int(df['3W客户数'].max())}家",
     f"超团队均值{df['3W客户数'].max()-kh_mean:.0f}家",
     '客户盘量最大'],
    ['TOP表现者（优爆品）', df.loc[df['当前优爆品数'].idxmax(),'销售'],
     f"{int(df['当前优爆品数'].max()):,}个",
     f"达成率{df.loc[df['当前优爆品数'].idxmax(),'优爆品目标达成率']:.1%}",
     '商品运营最强'],
    ['团队信保季度均值', '全体', f"{gmv_q_mean:,.0f}元", '—', '基准线'],
    ['团队ACP季度均值', '全体', f"{acp_q_mean:,.0f}元", '—', '基准线'],
    ['团队3W客户均值', '全体', f"{kh_mean:.1f}家", '—', '基准线'],
    ['团队优爆品均值', '全体', f"{yb_mean:.0f}个", '—', '基准线'],
    ['团队ACP渗透率均值', '全体', f"{acp_pct_mean:.2%}", '低于10%整体有提升空间', '重点关注'],
    ['团队优爆品达成率均值', '全体', f"{yb_rate_mean:.2%}", f"{'已整体达标' if yb_rate_mean>=1 else '部分成员未达标'}", '—'],
    ['赵舒越信保季度实收', '赵舒越', f"{int(zsy['信保季度实收']):,}元",
     f"同比+{zsy['信保季度同比']:.1%}，团队排名#{zsy['信保季度排名']}",
     '同比正增长，季度末冲刺中'],
    ['赵舒越ACP季度完成率', '赵舒越', f"{zsy['ACP季度完成率']:.1%}",
     f"实收{int(zsy['ACP季度实收']):,}元 vs 目标{int(zsy['ACP季度目标']):,}元",
     '未达标，有较大缺口'],
    ['赵舒越3W客户同比', '赵舒越', f"{int(zsy['3W客户数'])}家（同比-{int(zsy['同比3W客户数']-zsy['3W客户数'])}家）",
     '同比下滑，需关注留存',
     '重点跟进'],
    ['赵舒越优爆品达成率', '赵舒越', f"{zsy['优爆品目标达成率']:.1%}",
     f"当前{int(zsy['当前优爆品数']):,}个 vs 目标{int(zsy['优爆品季度目标']):,}个",
     '未满100%，季末冲刺'],
]
df_analysis = pd.DataFrame(analysis_rows, columns=['分析维度','对象','数值','详情','结论'])
build_table(ws7, data=df_analysis, anchor='B2',
    title='数据分析洞察 — 团队整体 & 赵舒越个人',
    theme='modern_finance',
    auto_width=True, band_rows=True)

# 汇总完整原始数据 Sheet
ws8 = wb.create_sheet('原始汇总数据')
ws8.sheet_view.showGridLines = False
build_table(ws8, data=df, anchor='A1',
    title='原始汇总数据（全字段）',
    theme='data_dense',
    column_formats={
        '信保月度实收':'simple_int','信保季度实收':'simple_int','信保年度实收':'simple_int',
        '信保月度同比':'pct_1','信保季度同比':'pct_1',
        'ACP月度实收':'simple_int','ACP月度目标':'simple_int','ACP季度实收':'simple_int',
        'ACP季度目标':'simple_int','ACP年度实收':'simple_int',
        'ACP月度完成率':'pct_1','ACP季度完成率':'pct_1',
        '3W客户数':'simple_int','同比3W客户数':'simple_int',
        '服务中客户数':'simple_int','当前有优爆品的客户数':'simple_int',
        '当前优爆品数':'simple_int','优爆品比例':'pct_1','优爆品季度目标':'simple_int',
        '优爆品目标达成率':'pct_1','p4p推广中优爆品数':'simple_int','优爆品p4p推广中比例':'pct_1',
        'ACP/信保渗透率':'pct_2','信保客单价（元/3W客）':'simple_int','爆品/客户覆盖比':'dec_1',
    },
    auto_width=True, band_rows=True)

# 调整顺序
sheet_order = ['销售汇总总览','信保GMV明细','ACP收入明细','3W客户数明细','优爆品明细','赵舒越个人业绩','数据分析洞察','原始汇总数据']
for i, name in enumerate(sheet_order):
    wb.move_sheet(name, offset=-(len(wb.sheetnames)-i))

wb.save(OUT)
print('DONE:', OUT)
