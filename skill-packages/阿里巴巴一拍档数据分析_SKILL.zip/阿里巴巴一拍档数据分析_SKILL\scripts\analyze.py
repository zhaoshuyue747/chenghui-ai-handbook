import sys, pandas as pd, numpy as np, warnings
sys.stdout.reconfigure(encoding='utf-8')
warnings.filterwarnings('ignore')
base = r'C:\Users\zhaos\Desktop\猪猪の文件\数据库'

# 目标设置
tgt = pd.read_excel(f'{base}/信保GMV.xlsx', sheet_name='目标设置', header=0)
tgt.columns = ['指标','4月激励','4月系统','5月激励','5月系统','6月激励','6月系统']
tgt = tgt[tgt['指标']!='公司'][['指标','6月激励','6月系统']].rename(columns={'指标':'销售'})
tgt['6月激励'] = pd.to_numeric(tgt['6月激励'], errors='coerce')
tgt['6月系统'] = pd.to_numeric(tgt['6月系统'], errors='coerce')

# 信保GMV销售
gmv = pd.read_excel(f'{base}/信保GMV.xlsx', sheet_name='销售数据', header=1)
gmv.columns = ['销售','销售主管','拍档','拍档id','生态主管','大区','月份',
               '信保月度实收','信保月度同比','信保季度实收','信保季度同比','信保年度实收','信保年度同比']
gmv['月份'] = pd.to_datetime(gmv['月份'], errors='coerce')
gmv = gmv[(gmv['月份']==pd.Timestamp('2026-06-01'))&(gmv['销售']!='-')].copy()

# ACP销售
acp = pd.read_excel(f'{base}/ACP收入.xlsx', sheet_name='销售数据', header=1)
acp.columns = ['销售','销售主管','拍档','拍档id','生态主管','大区','月份',
               'ACP月度实收','ACP月度同比','ACP月度目标','ACP月度完成率',
               'ACP季度实收','ACP季度同比','ACP季度目标','ACP季度完成率','ACP年度实收','ACP年度同比']
acp['月份'] = pd.to_datetime(acp['月份'], errors='coerce')
acp = acp[(acp['月份']==pd.Timestamp('2026-06-01'))&(acp['销售']!='-')].copy()

# 3W客户
kh = pd.read_excel(f'{base}/3万客户数.xlsx', sheet_name='销售数据')
kh = kh[kh['拍档销售']!='-'][['拍档销售','本季度3w客户数计数','同比季度3w客户数计数']].rename(
    columns={'拍档销售':'销售','本季度3w客户数计数':'3W客户数','同比季度3w客户数计数':'同比3W客户数'})

# 优爆品
yb = pd.read_excel(f'{base}/优爆品数据.xlsx', sheet_name='销售数据')[
    ['拍档销售','服务中客户数','当前有优爆品的客户数','当前优爆品数','当季度累计目标','当季度累计目标达成率']].rename(
    columns={'拍档销售':'销售','当季度累计目标':'优爆品季度目标','当季度累计目标达成率':'优爆品达成率'})

# 客户明细
cust = pd.read_excel(f'{base}/3万客户数.xlsx', sheet_name='客户数据')
cust['本季度GMV'] = pd.to_numeric(cust['本季度GMV'], errors='coerce').fillna(0)
cust['同比季度GMV'] = pd.to_numeric(cust['同比季度GMV'], errors='coerce').fillna(0)
cust['GMV下滑额'] = cust['同比季度GMV'] - cust['本季度GMV']
cust['GMV下滑率'] = np.where(cust['同比季度GMV']>0,
    (cust['本季度GMV']-cust['同比季度GMV'])/cust['同比季度GMV'], np.nan)
cust_down = cust[(cust['同比季度GMV']>0)&(cust['GMV下滑额']>0)].copy()
cust_grow = cust[(cust['同比季度GMV']>0)&(cust['GMV下滑额']<=0)].copy()

# 客户数据（ACP/星等级）
cust2 = pd.read_excel(f'{base}/客户数据.xlsx', sheet_name='客户数据')
print('客户数据列:', list(cust2.columns))

# 合并销售表
df = gmv[['销售','信保月度实收','信保月度同比','信保季度实收','信保季度同比']].merge(
     acp[['销售','ACP月度实收','ACP月度目标','ACP月度完成率','ACP季度实收','ACP季度目标','ACP季度完成率']], on='销售').merge(
     kh, on='销售').merge(yb, on='销售').merge(tgt, on='销售', how='left')

df['信保6月激励完成率'] = df['信保月度实收'] / df['6月激励']
df['信保6月系统完成率'] = df['信保月度实收'] / df['6月系统']
df['信保季度激励完成率'] = df['信保季度实收'] / (df['6月激励']*3)
df['信保季度系统完成率'] = df['信保季度实收'] / (df['6月系统']*3)
df['3W客户同比增减'] = df['3W客户数'] - df['同比3W客户数']
df['优爆品缺口'] = df['优爆品季度目标'] - df['当前优爆品数']
df['ACP缺口'] = df['ACP季度目标'] - df['ACP季度实收']
df['ACP渗透率'] = df['ACP月度实收'] / df['信保月度实收']

print('\n=== 各销售综合完成率 ===')
view = df[['销售','信保6月激励完成率','信保6月系统完成率','信保季度激励完成率','信保季度系统完成率',
           'ACP季度完成率','ACP缺口','3W客户数','3W客户同比增减','优爆品达成率','优爆品缺口','ACP渗透率']]
print(view.to_string(index=False))

print('\n=== 各销售下滑客户统计 ===')
for s in df['销售'].tolist():
    d = cust_down[cust_down['拍档销售']==s]
    g = cust_grow[cust_grow['拍档销售']==s]
    tot = cust[cust['拍档销售']==s]
    amt = int(d['GMV下滑额'].sum()) if len(d) else 0
    print(f'{s}: 服务{len(tot)}家 | 下滑{len(d)}家 增长/持平{len(g)}家 | 下滑总额{amt:,}元')
    if len(d) > 0:
        top3 = d.nlargest(3,'GMV下滑额')[['公司名称','本季度GMV','同比季度GMV','GMV下滑额','GMV下滑率','本季度分层']]
        for _, row in top3.iterrows():
            dr = row['GMV下滑率']*100 if pd.notna(row['GMV下滑率']) else 0
            print(f"    [{row['本季度分层']}] {row['公司名称']}  下滑{int(row['GMV下滑额']):,}元 ({dr:.0f}%)")
