"""
拍档业务仪表盘 v3
顺序：① 公司业绩 → ② 销售业绩 → ③ 各销售下滑TOP10客户
底色：明亮白色系，阿里蓝主色
"""
import sys
sys.path.insert(0, r'C:\Users\zhaos\.accio\accounts\1747555973_470001\skills\xlsx\scripts')
import pandas as pd, numpy as np, warnings
warnings.filterwarnings('ignore')
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from builders import build_table, build_chart
from style_kit import highlight_cells, add_data_bars, add_color_scale

BASE = r'C:\Users\zhaos\Desktop\猪猪の文件\数据库'
OUT  = r'C:\Users\zhaos\.accio\accounts\1747555973_470001\agents\DID-F456DA-15F456DAU1781073-7441-58F963\project\拍档业务仪表盘v4.xlsx'

# ══════════════════════════════════════════════════════
# 1. 数据加载
# ══════════════════════════════════════════════════════
# ── 信保GMV ──
gmv_co_raw = pd.read_excel(f'{BASE}/信保GMV.xlsx', sheet_name='公司数据', header=0)
# 15列：拍档/id/生态主管/大区/月份 | 月度实收/同比/目标/完成率 | 季度实收/同比/目标/完成率 | 年度实收/同比
gmv_co_raw.columns = ['拍档','拍档id','生态主管','大区','月份',
                      '信保月度实收','信保月度同比','信保月度目标','信保月度完成率',
                      '信保季度实收','信保季度同比','信保季度目标','信保季度完成率',
                      '信保年度实收','信保年度同比']
gmv_co_raw['月份'] = pd.to_datetime(gmv_co_raw['月份'], errors='coerce')
gmv_co_jun = gmv_co_raw[gmv_co_raw['月份']==pd.Timestamp('2026-06-01')].iloc[0]

gmv_sl_raw = pd.read_excel(f'{BASE}/信保GMV.xlsx', sheet_name='销售数据', header=1)
# 13列：销售/主管/拍档/id/生态主管/大区/月份 | 月度实收/同比 | 季度实收/同比 | 年度实收/同比
gmv_sl_raw.columns = ['销售','销售主管','拍档','拍档id','生态主管','大区','月份',
                      '信保月度实收','信保月度同比','信保季度实收','信保季度同比',
                      '信保年度实收','信保年度同比']
gmv_sl_raw['月份'] = pd.to_datetime(gmv_sl_raw['月份'], errors='coerce')
gmv_sl = gmv_sl_raw[(gmv_sl_raw['月份']==pd.Timestamp('2026-06-01'))&(gmv_sl_raw['销售']!='-')].copy()

# 目标设置（信保激励 & 系统两套目标）
tgt_raw = pd.read_excel(f'{BASE}/信保GMV.xlsx', sheet_name='目标设置', header=0)
tgt_raw.columns = ['指标','4月激励','4月系统','5月激励','5月系统','6月激励','6月系统']
tgt_raw = tgt_raw.dropna(subset=['指标'])
tgt_raw['6月激励'] = pd.to_numeric(tgt_raw['6月激励'], errors='coerce')
tgt_raw['6月系统'] = pd.to_numeric(tgt_raw['6月系统'], errors='coerce')
# 销售层目标（排除"公司"行）
tgt_sales = tgt_raw[tgt_raw['指标']!='公司'][['指标','6月激励','6月系统']].rename(
    columns={'指标':'销售','6月激励':'信保6月激励目标','6月系统':'信保6月系统目标'})
# 公司层目标
tgt_co_row = tgt_raw[tgt_raw['指标']=='公司'].iloc[0]
co_6m_sys_tgt = float(tgt_co_row['6月系统'])   # 公司6月系统目标
co_6m_ljl_tgt = float(tgt_co_row['6月激励']) if pd.notna(tgt_co_row['6月激励']) else None

# ── ACP收入 ──
acp_co_raw = pd.read_excel(f'{BASE}/ACP收入.xlsx', sheet_name='公司数据', header=1)
# 15列：拍档名/id/生态主管/大区/月份 | 月度实收/同比/目标/完成率 | 季度实收/同比/目标/完成率 | 年度实收/同比
acp_co_raw.columns = ['拍档','拍档id','生态主管','大区','月份',
                      'ACP月度实收','ACP月度同比','ACP月度目标','ACP月度完成率',
                      'ACP季度实收','ACP季度同比','ACP季度目标','ACP季度完成率',
                      'ACP年度实收','ACP年度同比']
acp_co_raw['月份'] = pd.to_datetime(acp_co_raw['月份'], errors='coerce')
acp_co_jun = acp_co_raw[acp_co_raw['月份']==pd.Timestamp('2026-06-01')].iloc[0]

acp_sl_raw = pd.read_excel(f'{BASE}/ACP收入.xlsx', sheet_name='销售数据', header=1)
# 17列：销售/主管/拍档名/id/生态主管/大区/月份 | 月度实收/同比/目标/完成率 | 季度实收/同比/目标/完成率 | 年度实收/同比
acp_sl_raw.columns = ['销售','销售主管','拍档','拍档id','生态主管','大区','月份',
                      'ACP月度实收','ACP月度同比','ACP月度目标','ACP月度完成率',
                      'ACP季度实收','ACP季度同比','ACP季度目标','ACP季度完成率',
                      'ACP年度实收','ACP年度同比']
acp_sl_raw['月份'] = pd.to_datetime(acp_sl_raw['月份'], errors='coerce')
acp_sl = acp_sl_raw[(acp_sl_raw['月份']==pd.Timestamp('2026-06-01'))&(acp_sl_raw['销售']!='-')].copy()

# ── 3W客户 ──
kh_sl = pd.read_excel(f'{BASE}/3万客户数.xlsx', sheet_name='销售数据')
kh_sl = kh_sl[kh_sl['拍档销售']!='-'][['拍档销售','本季度3w客户数计数','同比季度3w客户数计数']].rename(
    columns={'拍档销售':'销售','本季度3w客户数计数':'3W客户数','同比季度3w客户数计数':'同比3W客户数'})
kh_co = pd.read_excel(f'{BASE}/3万客户数.xlsx', sheet_name='公司数据').iloc[0]

# ── 优爆品 ──
yb_sl = pd.read_excel(f'{BASE}/优爆品数据.xlsx', sheet_name='销售数据')
yb_sl = yb_sl[['拍档销售','服务中客户数','当前有优爆品的客户数','当前优爆品数',
               '优爆品比例','当季度累计目标','当季度累计目标达成率']].rename(
    columns={'拍档销售':'销售','当季度累计目标':'优爆品季度目标','当季度累计目标达成率':'优爆品达成率'})
yb_co = pd.read_excel(f'{BASE}/优爆品数据.xlsx', sheet_name='公司数据').iloc[0]

# ── 客户下滑数据 ──
cust = pd.read_excel(f'{BASE}/3万客户数.xlsx', sheet_name='客户数据')
cust['本季度GMV']   = pd.to_numeric(cust['本季度GMV'],   errors='coerce').fillna(0)
cust['同比季度GMV'] = pd.to_numeric(cust['同比季度GMV'], errors='coerce').fillna(0)
cust['GMV下滑额']   = cust['同比季度GMV'] - cust['本季度GMV']
cust['GMV下滑率']   = np.where(cust['同比季度GMV']>0,
    (cust['本季度GMV']-cust['同比季度GMV'])/cust['同比季度GMV'], np.nan)
cust_down = cust[(cust['同比季度GMV']>0)&(cust['GMV下滑额']>0)].copy()

# ── 销售合并表 ──
df = gmv_sl[['销售','销售主管','信保月度实收','信保月度同比','信保季度实收','信保季度同比']].merge(
     acp_sl[['销售','ACP月度实收','ACP月度目标','ACP月度完成率','ACP季度实收','ACP季度目标','ACP季度完成率']], on='销售').merge(
     kh_sl, on='销售').merge(
     yb_sl[['销售','服务中客户数','当前优爆品数','优爆品季度目标','优爆品达成率']], on='销售')

# 合并激励目标 & 系统目标到销售表
df = df.merge(tgt_sales, on='销售', how='left')

# 6月完成率（激励口径 & 系统口径）
df['信保6月激励完成率'] = df['信保月度实收'] / df['信保6月激励目标']
df['信保6月系统完成率'] = df['信保月度实收'] / df['信保6月系统目标']

# 季度目标 = 各月目标之和（此处用激励×3 和 系统目标从公司数据取）
# 公司季度目标
gmv_co_jun_row = gmv_co_raw[gmv_co_raw['月份']==pd.Timestamp('2026-06-01')].iloc[0]
gmv_co_season_tgt_sys = float(gmv_co_jun_row['信保季度目标'])   # 公司季度系统目标

# 销售季度激励目标 = 6月激励目标 × 3（近似，无按月拆分数据时用此估算）
df['信保季度激励目标'] = df['信保6月激励目标'] * 3
df['信保季度系统目标'] = df['信保6月系统目标'] * 3
df['信保季度激励完成率'] = df['信保季度实收'] / df['信保季度激励目标']
df['信保季度系统完成率'] = df['信保季度实收'] / df['信保季度系统目标']

# 排名
df['信保月度排名'] = df['信保月度实收'].rank(ascending=False, method='min').astype(int)
df['信保季度排名'] = df['信保季度实收'].rank(ascending=False, method='min').astype(int)
df['ACP月度排名']  = df['ACP月度实收'].rank(ascending=False, method='min').astype(int)
df['ACP季度排名']  = df['ACP季度实收'].rank(ascending=False, method='min').astype(int)
df['3W客户排名']   = df['3W客户数'].rank(ascending=False, method='min').astype(int)
df['3W客户同比增减'] = df['3W客户数'] - df['同比3W客户数']

SALES_ORDER = df.sort_values('信保季度实收', ascending=False)['销售'].tolist()

# ══════════════════════════════════════════════════════
# 2. 样式常量
# ══════════════════════════════════════════════════════
C_BLUE   = '0070CC'
C_BLUE2  = '1890FF'
C_DEEP   = '002766'
C_BG     = 'FFFFFF'
C_BAND   = 'F0F7FF'
C_SEC    = 'E6F2FF'
C_GREEN  = '00A854'
C_RED    = 'F5222D'
C_ORANGE = 'FA8C16'
C_GRAY   = '8C8C8C'
C_BORDER = 'C8DFF5'

def F(size=10, bold=False, color=C_DEEP, name='Microsoft YaHei'):
    return Font(name=name, size=size, bold=bold, color=color)
def BG(c): return PatternFill('solid', fgColor=c)
def AL(h='center', v='center', wrap=False, indent=0):
    return Alignment(horizontal=h, vertical=v, wrap_text=wrap, indent=indent)
def BD(color=C_BORDER, all=True):
    s = Side(style='thin', color=color)
    return Border(left=s, right=s, top=s, bottom=s) if all else Border(bottom=s)

def banner(ws, row, col_s, col_e, text, sub='', bg1=C_BLUE, bg2=C_BLUE2):
    ws.row_dimensions[row].height = 46
    ws.merge_cells(start_row=row, start_column=col_s, end_row=row, end_column=col_e)
    c = ws.cell(row, col_s)
    c.value = text; c.fill = BG(bg1)
    c.font  = F(18, True, 'FFFFFF'); c.alignment = AL('center')
    if sub:
        ws.row_dimensions[row+1].height = 20
        ws.merge_cells(start_row=row+1, start_column=col_s, end_row=row+1, end_column=col_e)
        c2 = ws.cell(row+1, col_s)
        c2.value = sub; c2.fill = BG(bg2)
        c2.font  = F(10, False, 'FFFFFF'); c2.alignment = AL('center')
    return row + (2 if sub else 1)

def section(ws, row, col_s, col_e, text):
    ws.row_dimensions[row].height = 26
    ws.merge_cells(start_row=row, start_column=col_s, end_row=row, end_column=col_e)
    c = ws.cell(row, col_s)
    c.value = text; c.fill = BG(C_SEC)
    c.font  = F(11, True, C_BLUE)
    c.alignment = AL('left', indent=1)
    c.border = Border(left=Side(style='thick', color=C_BLUE),
                      bottom=Side(style='thin', color=C_BORDER))
    return row + 1

def kpi_card(ws, r, c, label, val, unit, note, note_color=C_GRAY, accent=C_BLUE):
    nc = c + 1
    lft = Side(style='thick', color=accent)
    brd = Side(style='thin', color=C_BORDER)
    for row in range(r, r+5):
        for col in [c, nc]:
            cl = ws.cell(row, col)
            cl.fill   = BG('FFFFFF')
            cl.border = Border(left=lft if col==c else brd,
                               right=brd, top=brd, bottom=brd)
    ws.row_dimensions[r  ].height = 12
    ws.row_dimensions[r+1].height = 18
    ws.row_dimensions[r+2].height = 36
    ws.row_dimensions[r+3].height = 16
    ws.row_dimensions[r+4].height = 16

    ws.cell(r+1, c).value = label
    ws.cell(r+1, c).font  = F(9, False, C_GRAY)
    ws.cell(r+1, c).alignment = AL('left', indent=1)
    ws.cell(r+1, c).fill = BG('FFFFFF')

    ws.merge_cells(start_row=r+2, start_column=c, end_row=r+2, end_column=nc)
    vc = ws.cell(r+2, c)
    vc.value = val; vc.fill = BG('FFFFFF')
    vc.font  = F(24, True, C_DEEP)
    vc.alignment = AL('left', indent=1)
    vc.number_format = '#,##0'

    ws.cell(r+3, c).value = unit
    ws.cell(r+3, c).font  = F(9, False, accent)
    ws.cell(r+3, c).alignment = AL('left', indent=1)
    ws.cell(r+3, c).fill = BG('FFFFFF')

    ws.merge_cells(start_row=r+4, start_column=c, end_row=r+4, end_column=nc)
    nc_ = ws.cell(r+4, c)
    nc_.value = note; nc_.fill = BG('FFFFFF')
    nc_.font  = F(8, False, note_color)
    nc_.alignment = AL('left', indent=1)

def pct_color(v):
    if pd.isna(v): return C_GRAY
    return C_GREEN if v >= 1.0 else C_ORANGE if v >= 0.8 else C_RED

# ══════════════════════════════════════════════════════
# Workbook
# ══════════════════════════════════════════════════════
wb = Workbook()
wb._named_styles['Normal'].font = Font(name='Microsoft YaHei', size=10)

# ══════════════════════════════════════════════════════
# SHEET 1: 公司业绩
# ══════════════════════════════════════════════════════
ws1 = wb.active
ws1.title = '公司业绩'
ws1.sheet_view.showGridLines = False
ws1.sheet_properties.tabColor = C_BLUE

COL_W1 = {1:2,2:18,3:18,4:18,5:18,6:18,7:18,8:18,9:18,10:18,11:18,12:2}
for c,w in COL_W1.items(): ws1.column_dimensions[get_column_letter(c)].width = w

ws1.row_dimensions[1].height = 8
r = banner(ws1, 2, 2, 11,
    '东莞市橙辉供应链管理有限公司  —  公司业绩总览',
    '深莞惠大区  ·  数据截至 2026-06-29  ·  FY27Q1')

r += 1
r = section(ws1, r, 2, 11, '▌ 核心指标看板')
r += 1

# 公司KPI卡片（信保月度、信保季度、ACP月度、ACP季度、3W客户、优爆品）
# 公司6月两套完成率
co_6m_act  = float(gmv_co_jun['信保月度实收'])
co_6m_sys  = float(gmv_co_jun['信保月度目标'])          # 公司数据里的目标=系统目标
co_6m_sys_rate  = co_6m_act / co_6m_sys
co_6m_ljl_rate  = (co_6m_act / co_6m_ljl_tgt) if co_6m_ljl_tgt else None
# 公司季度两套完成率
co_q_act   = float(gmv_co_jun['信保季度实收'])
co_q_sys   = float(gmv_co_jun['信保季度目标'])           # 系统目标
co_q_sys_rate   = co_q_act / co_q_sys
# 激励季度目标从目标设置读（目标设置只有6月，季度=各月激励之和，此处用6月系统目标对应的季度系统目标）
# 注：公司激励季度目标=各月激励之和，但目标设置表4/5月激励为空，仅有6月，故只展示系统口径季度
note_co_q  = f"系统口径季度完成率 {co_q_sys_rate:.1%}  系统目标 {int(co_q_sys):,}"
note_co_6m = (f"系统完成率 {co_6m_sys_rate:.1%}"
              + (f"  激励完成率 {co_6m_ljl_rate:.1%}" if co_6m_ljl_rate else ''))

cards = [
    ('信保6月实收', int(co_6m_act), '元', note_co_6m,
     pct_color(co_6m_sys_rate), C_BLUE, 2),
    ('信保季度实收', int(co_q_act), '元', note_co_q,
     pct_color(co_q_sys_rate), C_BLUE2, 4),
    ('ACP 6月实收', int(acp_co_jun['ACP月度实收']), '元',
     f"月度完成率 {float(acp_co_jun['ACP月度完成率']):.1%}",
     pct_color(float(acp_co_jun['ACP月度完成率'])), 'FA8C16', 6),
    ('ACP 季度实收', int(acp_co_jun['ACP季度实收']), '元',
     f"季度完成率 {float(acp_co_jun['ACP季度完成率']):.1%}  目标 {int(float(acp_co_jun['ACP季度目标'])):,}",
     pct_color(float(acp_co_jun['ACP季度完成率'])), 'FA8C16', 8),
    ('3W 活跃客户数', int(kh_co['活跃客户数']), '家',
     f"同比 {float(kh_co['当前/同比同期']):.1%}",
     C_GREEN if float(kh_co['当前/同比同期'])>=1 else C_RED, C_GREEN, 10),
]
for label,val,unit,note,nc_,accent,col in cards:
    kpi_card(ws1, r, col, label, val, unit, note, nc_, accent)

r += 6

# 公司优爆品单行
ws1.row_dimensions[r].height = 26
ws1.merge_cells(f'B{r}:K{r}')
yb_c = ws1[f'B{r}']
yb_c.value = (f"  优爆品3.0   当前优爆品数：{int(yb_co['当前优爆品数']):,} 个   "
              f"季度达成率：{float(yb_co['当季度累计目标达成率']):.1%}   "
              f"目标：{int(yb_co['当季度累计目标']):,} 个")
yb_c.fill = BG(C_SEC); yb_c.font = F(11, True, C_BLUE)
yb_c.alignment = AL('left', indent=2)
r += 2

# ── 公司月度趋势表（信保） ──
r = section(ws1, r, 2, 11, '▌ 信保GMV月度趋势（公司级）')
r += 1
gmv_trend = gmv_co_raw[['月份','信保月度实收','信保月度同比','信保月度目标','信保月度完成率',
                          '信保季度实收','信保季度同比']].copy()
gmv_trend['月份'] = gmv_trend['月份'].dt.strftime('%Y-%m')
gmv_trend.columns = ['月份','信保月度实收（元）','月度同比','月度目标（元）','月度完成率','季度累计实收（元）','季度同比']
t_gmv = build_table(ws1, data=gmv_trend, anchor=f'B{r}',
    theme='vibrant_marketing',
    column_formats={'信保月度实收（元）':'simple_int','月度目标（元）':'simple_int',
                    '季度累计实收（元）':'simple_int','月度同比':'pct_1',
                    '月度完成率':'pct_1','季度同比':'pct_1'},
    auto_width=True, band_rows=True)
highlight_cells(ws1, t_gmv, rules=[
    {'column':'月度完成率','when':'ge','value':1.0,'style':'green_fill'},
    {'column':'月度完成率','when':'lt','value':0.85,'style':'red_fill'},
    {'column':'月度同比','when':'gt','value':0,'style':'green_text'},
    {'column':'月度同比','when':'lt','value':0,'style':'red_text'},
])
build_chart(ws1, kind='combo_bar_line',
    data_range=f"'公司业绩'!B{t_gmv['header_row']}:C{t_gmv['data_rows'][1]},"
               f"'公司业绩'!E{t_gmv['header_row']}:E{t_gmv['data_rows'][1]}",
    series_orient='cols', title='信保月度实收 vs 目标（元）',
    anchor=f'J{r}', size=(520,260), theme='vibrant_marketing',
    legend='bottom', gridlines='horizontal_dashed', y_axis_min='zero', y_number_format='int',
    combo_line_series=[-1])
r = t_gmv['data_rows'][1] + 3

# ── ACP月度趋势 ──
r = section(ws1, r, 2, 11, '▌ ACP收入月度趋势（公司级）')
r += 1
acp_trend = acp_co_raw[['月份','ACP月度实收','ACP月度同比','ACP月度目标','ACP月度完成率',
                          'ACP季度实收','ACP季度完成率']].copy()
acp_trend['月份'] = acp_trend['月份'].dt.strftime('%Y-%m')
acp_trend.columns = ['月份','ACP月度实收（元）','月度同比','月度目标（元）','月度完成率','季度累计实收（元）','季度完成率']
t_acp = build_table(ws1, data=acp_trend, anchor=f'B{r}',
    theme='vibrant_marketing',
    column_formats={'ACP月度实收（元）':'simple_int','月度目标（元）':'simple_int',
                    '季度累计实收（元）':'simple_int','月度同比':'pct_1',
                    '月度完成率':'pct_1','季度完成率':'pct_1'},
    auto_width=True, band_rows=True)
highlight_cells(ws1, t_acp, rules=[
    {'column':'月度完成率','when':'ge','value':1.0,'style':'green_fill'},
    {'column':'月度完成率','when':'lt','value':0.85,'style':'red_fill'},
    {'column':'季度完成率','when':'ge','value':1.0,'style':'green_fill'},
    {'column':'季度完成率','when':'lt','value':0.85,'style':'amber_fill'},
])
r = t_acp['data_rows'][1] + 3

# ══════════════════════════════════════════════════════
# SHEET 2: 销售业绩
# ══════════════════════════════════════════════════════
ws2 = wb.create_sheet('销售业绩')
ws2.sheet_view.showGridLines = False
ws2.sheet_properties.tabColor = '1890FF'

for c,w in COL_W1.items(): ws2.column_dimensions[get_column_letter(c)].width = w

ws2.row_dimensions[1].height = 8
r2 = banner(ws2, 2, 2, 11,
    '各销售业绩排行榜  —  FY27Q1',
    '信保GMV / ACP收入 / 3W客户数 / 优爆品  ·  6月完成率 & 季度完成率')

r2 += 1
r2 = section(ws2, r2, 2, 11, '▌ 销售综合业绩汇总（按信保季度实收降序）')
r2 += 1

# 主汇总表（含信保激励/系统两套完成率）
sl_view = df[['销售','销售主管',
              '信保月度实收','信保6月激励目标','信保6月激励完成率',
              '信保6月系统目标','信保6月系统完成率',
              '信保月度同比','信保月度排名',
              '信保季度实收','信保季度激励目标','信保季度激励完成率',
              '信保季度系统目标','信保季度系统完成率',
              '信保季度同比','信保季度排名',
              'ACP月度实收','ACP月度目标','ACP月度完成率','ACP月度排名',
              'ACP季度实收','ACP季度目标','ACP季度完成率','ACP季度排名',
              '3W客户数','同比3W客户数','3W客户同比增减','3W客户排名',
              '当前优爆品数','优爆品季度目标','优爆品达成率']].sort_values('信保季度实收',ascending=False).copy()

t_sl = build_table(ws2, data=sl_view, anchor=f'B{r2}',
    title='拍档团队销售业绩综合排行  FY27Q1（截至2026-06-29）  ★信保含激励/系统两套完成率',
    theme='vibrant_marketing',
    column_formats={
        '信保月度实收':'simple_int',
        '信保6月激励目标':'simple_int','信保6月激励完成率':'pct_1',
        '信保6月系统目标':'simple_int','信保6月系统完成率':'pct_1',
        '信保月度同比':'pct_1',
        '信保季度实收':'simple_int',
        '信保季度激励目标':'simple_int','信保季度激励完成率':'pct_1',
        '信保季度系统目标':'simple_int','信保季度系统完成率':'pct_1',
        '信保季度同比':'pct_1',
        'ACP月度实收':'simple_int','ACP月度目标':'simple_int','ACP月度完成率':'pct_1',
        'ACP季度实收':'simple_int','ACP季度目标':'simple_int','ACP季度完成率':'pct_1',
        '3W客户数':'simple_int','同比3W客户数':'simple_int','3W客户同比增减':'simple_int',
        '当前优爆品数':'simple_int','优爆品季度目标':'simple_int','优爆品达成率':'pct_1',
    }, auto_width=True, band_rows=True, total_row=False)

highlight_cells(ws2, t_sl, rules=[
    # 信保6月激励完成率
    {'column':'信保6月激励完成率','when':'ge','value':1.0,'style':'green_fill'},
    {'column':'信保6月激励完成率','when':'lt','value':0.8,'style':'red_fill'},
    # 信保6月系统完成率
    {'column':'信保6月系统完成率','when':'ge','value':1.0,'style':'green_fill'},
    {'column':'信保6月系统完成率','when':'lt','value':0.8,'style':'red_fill'},
    # 信保季度激励完成率
    {'column':'信保季度激励完成率','when':'ge','value':1.0,'style':'green_fill'},
    {'column':'信保季度激励完成率','when':'lt','value':0.8,'style':'red_fill'},
    # 信保季度系统完成率
    {'column':'信保季度系统完成率','when':'ge','value':1.0,'style':'green_fill'},
    {'column':'信保季度系统完成率','when':'lt','value':0.8,'style':'red_fill'},
    {'column':'信保月度同比','when':'gt','value':0,'style':'green_text'},
    {'column':'信保月度同比','when':'lt','value':0,'style':'red_text'},
    {'column':'信保月度排名','when':'le','value':3,'style':'green_fill'},
    {'column':'信保季度排名','when':'le','value':3,'style':'green_fill'},
    {'column':'ACP月度完成率','when':'ge','value':1.0,'style':'green_fill'},
    {'column':'ACP月度完成率','when':'lt','value':0.7,'style':'red_fill'},
    {'column':'ACP季度完成率','when':'ge','value':1.0,'style':'green_fill'},
    {'column':'ACP季度完成率','when':'lt','value':0.7,'style':'red_fill'},
    {'column':'ACP月度排名','when':'le','value':3,'style':'green_fill'},
    {'column':'ACP季度排名','when':'le','value':3,'style':'green_fill'},
    {'column':'3W客户同比增减','when':'gt','value':0,'style':'green_text'},
    {'column':'3W客户同比增减','when':'lt','value':0,'style':'red_text'},
    {'column':'3W客户排名','when':'le','value':3,'style':'green_fill'},
    {'column':'优爆品达成率','when':'ge','value':1.0,'style':'green_fill'},
    {'column':'优爆品达成率','when':'lt','value':0.85,'style':'amber_fill'},
])
add_data_bars(ws2, t_sl, columns=['信保月度实收'], color='sky')
add_data_bars(ws2, t_sl, columns=['信保季度实收'], color='sky')
add_data_bars(ws2, t_sl, columns=['ACP月度实收'],  color='peach')
add_data_bars(ws2, t_sl, columns=['ACP季度实收'],  color='peach')
add_data_bars(ws2, t_sl, columns=['3W客户数'],     color='mint')
add_data_bars(ws2, t_sl, columns=['当前优爆品数'],  color='lavender')

chart_r2 = t_sl['data_rows'][1] + 3

# 信保季度排行图
build_chart(ws2, kind='clustered_bar',
    data_range=f"'销售业绩'!B{t_sl['header_row']}:B{t_sl['data_rows'][1]},"
               f"'销售业绩'!I{t_sl['header_row']}:I{t_sl['data_rows'][1]}",
    series_orient='cols', title='信保季度实收排行（元）',
    anchor=f'B{chart_r2}', size=(580,300), theme='vibrant_marketing',
    legend='none', gridlines='horizontal_dashed', y_axis_min='zero', y_number_format='int')

build_chart(ws2, kind='clustered_bar',
    data_range=f"'销售业绩'!B{t_sl['header_row']}:B{t_sl['data_rows'][1]},"
               f"'销售业绩'!O{t_sl['header_row']}:O{t_sl['data_rows'][1]}",
    series_orient='cols', title='ACP季度实收排行（元）',
    anchor=f'J{chart_r2}', size=(400,300), theme='vibrant_marketing',
    legend='none', gridlines='horizontal_dashed', y_axis_min='zero', y_number_format='int')

# ── 6月完成率对比 ──
next_r2 = chart_r2 + 20
next_r2 = section(ws2, next_r2, 2, 11, '▌ 6月信保完成率 & ACP完成率  —  各销售对比')
next_r2 += 1

rate_view = df[['销售',
                '信保月度实收',
                '信保6月激励目标','信保6月激励完成率',
                '信保6月系统目标','信保6月系统完成率',
                '信保月度同比',
                '信保季度实收',
                '信保季度激励目标','信保季度激励完成率',
                '信保季度系统目标','信保季度系统完成率',
                'ACP月度实收','ACP月度目标','ACP月度完成率',
                'ACP季度实收','ACP季度目标','ACP季度完成率',
                ]].sort_values('信保6月激励完成率', ascending=False).copy()

t_rate = build_table(ws2, data=rate_view, anchor=f'B{next_r2}',
    title='信保（激励/系统双口径）& ACP  6月+季度完成率对比',
    theme='vibrant_marketing',
    column_formats={
        '信保月度实收':'simple_int','信保月度同比':'pct_1',
        '信保6月激励目标':'simple_int','信保6月激励完成率':'pct_1',
        '信保6月系统目标':'simple_int','信保6月系统完成率':'pct_1',
        '信保季度实收':'simple_int',
        '信保季度激励目标':'simple_int','信保季度激励完成率':'pct_1',
        '信保季度系统目标':'simple_int','信保季度系统完成率':'pct_1',
        'ACP月度实收':'simple_int','ACP月度目标':'simple_int','ACP月度完成率':'pct_1',
        'ACP季度实收':'simple_int','ACP季度目标':'simple_int','ACP季度完成率':'pct_1',
    }, auto_width=True, band_rows=True)
highlight_cells(ws2, t_rate, rules=[
    {'column':'信保6月激励完成率','when':'ge','value':1.0,'style':'green_fill'},
    {'column':'信保6月激励完成率','when':'lt','value':0.85,'style':'red_fill'},
    {'column':'信保6月系统完成率','when':'ge','value':1.0,'style':'green_fill'},
    {'column':'信保6月系统完成率','when':'lt','value':0.85,'style':'red_fill'},
    {'column':'信保季度激励完成率','when':'ge','value':1.0,'style':'green_fill'},
    {'column':'信保季度激励完成率','when':'lt','value':0.85,'style':'red_fill'},
    {'column':'信保季度系统完成率','when':'ge','value':1.0,'style':'green_fill'},
    {'column':'信保季度系统完成率','when':'lt','value':0.85,'style':'red_fill'},
    {'column':'ACP月度完成率','when':'ge','value':1.0,'style':'green_fill'},
    {'column':'ACP月度完成率','when':'lt','value':0.7,'style':'red_fill'},
    {'column':'ACP季度完成率','when':'ge','value':1.0,'style':'green_fill'},
    {'column':'ACP季度完成率','when':'lt','value':0.7,'style':'red_fill'},
    {'column':'信保月度同比','when':'gt','value':0,'style':'green_text'},
    {'column':'信保月度同比','when':'lt','value':0,'style':'red_text'},
])
add_color_scale(ws2, t_rate, columns=['信保6月激励完成率'], scale='red_white_green')
add_color_scale(ws2, t_rate, columns=['信保6月系统完成率'],  scale='red_white_green')
add_color_scale(ws2, t_rate, columns=['信保季度激励完成率'], scale='red_white_green')
add_color_scale(ws2, t_rate, columns=['信保季度系统完成率'],  scale='red_white_green')

# ══════════════════════════════════════════════════════
# SHEET 3: 各销售下滑TOP10客户
# ══════════════════════════════════════════════════════
ws3 = wb.create_sheet('客户GMV下滑分析')
ws3.sheet_view.showGridLines = False
ws3.sheet_properties.tabColor = C_RED

for c in range(1,10): ws3.column_dimensions[get_column_letter(c)].width = 20
ws3.column_dimensions['B'].width = 32

r3 = banner(ws3, 1, 1, 9,
    '各销售  客户GMV下滑 TOP10  —  FY27Q1 vs 同比',
    '口径：本季度GMV < 同比季度GMV  ·  按下滑金额降序',
    bg1=C_RED, bg2='FF4D4F')

ACCENT_MAP = {
    '高盛强':'0050B3','燕磊':'C05000','杨婷婷':'006D36',
    '欧阳杰俊':'531DAB','赵舒越':'00718C','刘鑫':'7B3800',
    '李朝燕':'876800','杨佳玮':'135200','狄鹏':'780650',
}

for sales in SALES_ORDER:
    sub = cust_down[cust_down['拍档销售']==sales].copy()
    if sub.empty: continue

    top10 = sub.nlargest(10,'GMV下滑额')[
        ['公司名称','本季度GMV','同比季度GMV','GMV下滑额','GMV下滑率','本季度分层','同比季度分层']
    ].copy()
    top10.insert(0,'排名', range(1, len(top10)+1))
    top10 = top10.rename(columns={
        '公司名称':'客户名称','本季度GMV':'本季度GMV（元）','同比季度GMV':'同比GMV（元）',
        'GMV下滑额':'下滑金额（元）','GMV下滑率':'下滑率','本季度分层':'本季分层','同比季度分层':'同比分层'
    })

    r3 += 1
    accent = ACCENT_MAP.get(sales, C_BLUE)
    ws3.row_dimensions[r3].height = 26
    ws3.merge_cells(start_row=r3, start_column=1, end_row=r3, end_column=9)
    hc = ws3.cell(r3, 1)
    hc.value = (f'  {sales}  ·  下滑客户合计 {len(sub)} 家'
                f'  ·  下滑总额 {int(sub["GMV下滑额"].sum()):,} 元  ·  展示前10')
    hc.fill = BG(accent)
    hc.font = Font(name='Microsoft YaHei', size=11, bold=True, color='FFFFFF')
    hc.alignment = AL('left', indent=1)
    r3 += 1

    t3 = build_table(ws3, data=top10, anchor=f'A{r3}',
        theme='vibrant_marketing',
        column_formats={'本季度GMV（元）':'simple_int','同比GMV（元）':'simple_int',
                        '下滑金额（元）':'simple_int','下滑率':'pct_1'},
        auto_width=True, band_rows=True)
    highlight_cells(ws3, t3, rules=[
        {'column':'下滑率','when':'lt','value':-0.5,'style':'red_fill'},
        {'column':'下滑率','when':'between','value':(-0.5,-0.2),'style':'amber_fill'},
        {'column':'排名','when':'eq','value':1,'style':'red_text'},
    ])
    add_data_bars(ws3, t3, columns=['下滑金额（元）'], color='rose')
    r3 = t3['data_rows'][1] + 3

# ── Sheet顺序 ──
for i, name in enumerate(['公司业绩','销售业绩','客户GMV下滑分析']):
    wb.move_sheet(name, offset=-(len(wb.sheetnames)-i))

wb.save(OUT)
print('DONE:', OUT)
