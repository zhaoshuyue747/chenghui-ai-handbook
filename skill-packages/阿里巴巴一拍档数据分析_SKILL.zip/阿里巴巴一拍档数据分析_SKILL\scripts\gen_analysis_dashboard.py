"""
销售提升维度分析仪表盘
结构：① 团队雷达/综合评分 → ② 各销售提升维度矩阵 → ③ 各销售重点客户清单
"""
import sys
sys.path.insert(0, r'C:\Users\zhaos\.accio\accounts\1747555973_470001\skills\xlsx\scripts')
import pandas as pd, numpy as np, warnings
warnings.filterwarnings('ignore')
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.chart import RadarChart, Reference, BarChart
from openpyxl.chart.series import SeriesLabel
from builders import build_table, build_chart
from style_kit import highlight_cells, add_data_bars, add_color_scale, add_icon_set

BASE = r'C:\Users\zhaos\Desktop\猪猪の文件\数据库'
OUT  = r'C:\Users\zhaos\.accio\accounts\1747555973_470001\agents\DID-F456DA-15F456DAU1781073-7441-58F963\project\销售提升维度分析仪表盘.xlsx'

# ══════════════════════════════════════════
# 数据加载
# ══════════════════════════════════════════
tgt = pd.read_excel(f'{BASE}/信保GMV.xlsx', sheet_name='目标设置', header=0)
tgt.columns = ['指标','4月激励','4月系统','5月激励','5月系统','6月激励','6月系统']
tgt = tgt[tgt['指标']!='公司'][['指标','6月激励','6月系统']].rename(columns={'指标':'销售'})
tgt['6月激励'] = pd.to_numeric(tgt['6月激励'], errors='coerce')
tgt['6月系统'] = pd.to_numeric(tgt['6月系统'], errors='coerce')

gmv = pd.read_excel(f'{BASE}/信保GMV.xlsx', sheet_name='销售数据', header=1)
gmv.columns = ['销售','销售主管','拍档','拍档id','生态主管','大区','月份',
               '信保月度实收','信保月度同比','信保季度实收','信保季度同比','信保年度实收','信保年度同比']
gmv['月份'] = pd.to_datetime(gmv['月份'], errors='coerce')
gmv = gmv[(gmv['月份']==pd.Timestamp('2026-06-01'))&(gmv['销售']!='-')].copy()

acp = pd.read_excel(f'{BASE}/ACP收入.xlsx', sheet_name='销售数据', header=1)
acp.columns = ['销售','销售主管','拍档','拍档id','生态主管','大区','月份',
               'ACP月度实收','ACP月度同比','ACP月度目标','ACP月度完成率',
               'ACP季度实收','ACP季度同比','ACP季度目标','ACP季度完成率','ACP年度实收','ACP年度同比']
acp['月份'] = pd.to_datetime(acp['月份'], errors='coerce')
acp = acp[(acp['月份']==pd.Timestamp('2026-06-01'))&(acp['销售']!='-')].copy()

kh = pd.read_excel(f'{BASE}/3万客户数.xlsx', sheet_name='销售数据')
kh = kh[kh['拍档销售']!='-'][['拍档销售','本季度3w客户数计数','同比季度3w客户数计数']].rename(
    columns={'拍档销售':'销售','本季度3w客户数计数':'3W客户数','同比季度3w客户数计数':'同比3W客户数'})

yb = pd.read_excel(f'{BASE}/优爆品数据.xlsx', sheet_name='销售数据')[
    ['拍档销售','服务中客户数','当前有优爆品的客户数','当前优爆品数','当季度累计目标','当季度累计目标达成率']].rename(
    columns={'拍档销售':'销售','当季度累计目标':'优爆品季度目标','当季度累计目标达成率':'优爆品达成率'})

cust = pd.read_excel(f'{BASE}/3万客户数.xlsx', sheet_name='客户数据')
cust['本季度GMV']   = pd.to_numeric(cust['本季度GMV'],   errors='coerce').fillna(0)
cust['同比季度GMV'] = pd.to_numeric(cust['同比季度GMV'], errors='coerce').fillna(0)
cust['GMV下滑额']   = cust['同比季度GMV'] - cust['本季度GMV']
cust['GMV下滑率']   = np.where(cust['同比季度GMV']>0,
    (cust['本季度GMV']-cust['同比季度GMV'])/cust['同比季度GMV'], np.nan)
cust_down = cust[(cust['同比季度GMV']>0)&(cust['GMV下滑额']>0)].copy()

df = gmv[['销售','信保月度实收','信保月度同比','信保季度实收','信保季度同比']].merge(
     acp[['销售','ACP月度实收','ACP月度目标','ACP月度完成率',
          'ACP季度实收','ACP季度目标','ACP季度完成率']], on='销售').merge(
     kh, on='销售').merge(yb, on='销售').merge(tgt, on='销售', how='left')

df['信保激励完成率'] = df['信保月度实收'] / df['6月激励']
df['信保系统完成率'] = df['信保月度实收'] / df['6月系统']
df['信保季度激励完成率'] = df['信保季度实收'] / (df['6月激励']*3)
df['信保季度系统完成率'] = df['信保季度实收'] / (df['6月系统']*3)
df['3W客户同比增减']  = df['3W客户数'] - df['同比3W客户数']
df['优爆品缺口']      = (df['优爆品季度目标'] - df['当前优爆品数']).clip(lower=0)
df['ACP季度缺口']     = (df['ACP季度目标'] - df['ACP季度实收']).clip(lower=0)
df['ACP渗透率']       = df['ACP月度实收'] / df['信保月度实收']

# 优先级判断（综合最弱维度数量）
def priority(row):
    weak = 0
    if row['信保激励完成率'] < 0.85: weak += 2
    if row['信保系统完成率'] < 0.85: weak += 2
    if row['ACP季度完成率']  < 0.85: weak += 1
    if row['优爆品达成率']   < 0.90: weak += 1
    if row['3W客户同比增减'] < -2:   weak += 1
    if weak >= 4: return 'P0 🔴'
    if weak >= 2: return 'P1 🟠'
    if weak >= 1: return 'P2 🟡'
    return 'P3 🟢'

df['行动优先级'] = df.apply(priority, axis=1)

# 各维度是否需提升（1=需提升）
df['需提升_信保激励'] = (df['信保激励完成率'] < 1.0).astype(int)
df['需提升_信保系统'] = (df['信保系统完成率'] < 1.0).astype(int)
df['需提升_ACP']      = (df['ACP季度完成率']  < 1.0).astype(int)
df['需提升_优爆品']   = (df['优爆品达成率']   < 1.0).astype(int)
df['需提升_3W客户']   = (df['3W客户同比增减'] < 0).astype(int)
df['提升维度数']      = df[['需提升_信保激励','需提升_信保系统','需提升_ACP','需提升_优爆品','需提升_3W客户']].sum(axis=1)

SALES_ORDER = df.sort_values('提升维度数', ascending=False)['销售'].tolist()

# ══════════════════════════════════════════
# 样式工具
# ══════════════════════════════════════════
C_BLUE   = '0070CC'
C_DEEP   = '002766'
C_RED    = 'F5222D'
C_RED2   = 'FFF1F0'
C_ORANGE = 'FA8C16'
C_ORG2   = 'FFF7E6'
C_GREEN  = '00A854'
C_GRN2   = 'F6FFED'
C_YELLOW = 'FADB14'
C_GRAY   = '8C8C8C'
C_SEC    = 'E6F2FF'
C_BORDER = 'C8DFF5'
C_BG     = 'FFFFFF'

def F(size=10, bold=False, color=C_DEEP): return Font(name='Microsoft YaHei', size=size, bold=bold, color=color)
def BG(c): return PatternFill('solid', fgColor=c)
def AL(h='center', v='center', wrap=False, indent=0): return Alignment(horizontal=h, vertical=v, wrap_text=wrap, indent=indent)
def BD(color=C_BORDER):
    s = Side(style='thin', color=color)
    return Border(left=s, right=s, top=s, bottom=s)

def banner(ws, row, c1, c2, title, sub='', bg1=C_BLUE, bg2='1890FF'):
    ws.row_dimensions[row].height = 46
    ws.merge_cells(start_row=row, start_column=c1, end_row=row, end_column=c2)
    c = ws.cell(row, c1)
    c.value = title; c.fill = BG(bg1)
    c.font  = F(18, True, 'FFFFFF'); c.alignment = AL('center')
    if sub:
        ws.row_dimensions[row+1].height = 20
        ws.merge_cells(start_row=row+1, start_column=c1, end_row=row+1, end_column=c2)
        c2_ = ws.cell(row+1, c1)
        c2_.value = sub; c2_.fill = BG(bg2)
        c2_.font  = F(10, False, 'FFFFFF'); c2_.alignment = AL('center')
    return row + (2 if sub else 1)

def section_title(ws, row, c1, c2, text):
    ws.row_dimensions[row].height = 26
    ws.merge_cells(start_row=row, start_column=c1, end_row=row, end_column=c2)
    c = ws.cell(row, c1)
    c.value = text; c.fill = BG(C_SEC)
    c.font  = F(11, True, C_BLUE)
    c.alignment = AL('left', indent=1)
    c.border = Border(left=Side(style='thick', color=C_BLUE), bottom=Side(style='thin', color=C_BORDER))
    return row + 1

def tag_cell(ws, row, col, text, bg, fg='FFFFFF', size=9, bold=True):
    c = ws.cell(row, col)
    c.value = text; c.fill = BG(bg)
    c.font  = Font(name='Microsoft YaHei', size=size, bold=bold, color=fg)
    c.alignment = AL('center')
    c.border = BD()
    return c

def check_cell(ws, row, col, need, val_str='', size=10):
    """打勾/打叉/数值的状态单元格"""
    c = ws.cell(row, col)
    if need == 'ok':
        c.value = '达标'; c.fill = BG(C_GRN2)
        c.font = Font(name='Microsoft YaHei', size=size, bold=True, color=C_GREEN)
    elif need == 'warn':
        c.value = val_str or '待提升'; c.fill = BG(C_ORG2)
        c.font = Font(name='Microsoft YaHei', size=size, bold=True, color=C_ORANGE)
    elif need == 'bad':
        c.value = val_str or '未达标'; c.fill = BG(C_RED2)
        c.font = Font(name='Microsoft YaHei', size=size, bold=True, color=C_RED)
    else:
        c.value = val_str; c.fill = BG('F5F5F5')
        c.font = Font(name='Microsoft YaHei', size=size, color=C_GRAY)
    c.alignment = AL('center')
    c.border = BD()

# ══════════════════════════════════════════
# Workbook
# ══════════════════════════════════════════
wb = Workbook()
wb._named_styles['Normal'].font = Font(name='Microsoft YaHei', size=10)

# ══════════════════════════════════════════
# SHEET 1: 提升维度综合评分矩阵
# ══════════════════════════════════════════
ws1 = wb.active
ws1.title = '提升维度评分矩阵'
ws1.sheet_view.showGridLines = False
ws1.sheet_properties.tabColor = C_BLUE

COL_W = {1:2, 2:14, 3:14, 4:13, 5:13, 6:13, 7:13, 8:13, 9:10, 10:12, 11:14, 12:16, 13:2}
for c, w in COL_W.items(): ws1.column_dimensions[get_column_letter(c)].width = w

ws1.row_dimensions[1].height = 8
r = banner(ws1, 2, 2, 12,
    '拍档团队  销售提升维度分析仪表盘  FY27Q1',
    '基于信保GMV（激励/系统双口径）· ACP · 3W客户 · 优爆品 四大维度综合评估')
r += 1

# ── 图例说明 ──
r = section_title(ws1, r, 2, 12, '▌ 图例说明')
r += 1
ws1.row_dimensions[r].height = 22
for col, (txt, bg, fg) in enumerate([
    ('P0 🔴 紧急', C_RED, 'FFFFFF'), ('P1 🟠 重要', 'FA8C16', 'FFFFFF'),
    ('P2 🟡 一般', 'FADB14', C_DEEP), ('P3 🟢 良好', C_GREEN, 'FFFFFF'),
    ('达标 ✓', C_GRN2, C_GREEN), ('待提升 △', C_ORG2, C_ORANGE), ('未达标 ✗', C_RED2, C_RED),
], start=2):
    c = ws1.cell(r, col)
    c.value = txt; c.fill = BG(bg)
    c.font  = Font(name='Microsoft YaHei', size=9, bold=True, color=fg)
    c.alignment = AL('center'); c.border = BD()
r += 2

# ── 评分矩阵主表 ──
r = section_title(ws1, r, 2, 12, '▌ 各销售提升维度评分矩阵（按紧迫程度排序）')
r += 1

# 表头
headers = ['销售', '行动\n优先级', '信保\n激励完成率', '信保\n系统完成率',
           'ACP季度\n完成率', '优爆品\n达成率', '3W客户\n同比增减',
           '提升维度数', 'ACP季度缺口', '优爆品缺口', '综合判断']
col_widths_hdr = [14,10,13,13,13,13,13,10,12,10,20]
for ci, (h, w) in enumerate(zip(headers, col_widths_hdr), start=2):
    ws1.column_dimensions[get_column_letter(ci)].width = w
    c = ws1.cell(r, ci)
    c.value = h; c.fill = BG(C_BLUE)
    c.font  = F(9, True, 'FFFFFF')
    c.alignment = AL('center', wrap=True); c.border = BD()
ws1.row_dimensions[r].height = 32
r += 1

# 按提升维度数降序排列
df_sorted = df.sort_values(['提升维度数','ACP季度缺口'], ascending=[False, False])

for _, row_data in df_sorted.iterrows():
    ws1.row_dimensions[r].height = 30
    sales = row_data['销售']
    pri   = row_data['行动优先级']

    # 优先级颜色
    pri_bg = {'P0 🔴': C_RED, 'P1 🟠': 'FA8C16', 'P2 🟡': 'FADB14', 'P3 🟢': C_GREEN}.get(pri, C_GRAY)
    pri_fg = {'P0 🔴': 'FFFFFF', 'P1 🟠': 'FFFFFF', 'P2 🟡': C_DEEP, 'P3 🟢': 'FFFFFF'}.get(pri, 'FFFFFF')

    # 销售姓名
    c = ws1.cell(r, 2); c.value = sales
    c.font = F(11, True, C_DEEP); c.alignment = AL('center'); c.border = BD()
    c.fill = BG('FAFAFA')

    # 优先级
    tag_cell(ws1, r, 3, pri, pri_bg, pri_fg)

    # 信保激励完成率
    v = row_data['信保激励完成率']
    status = 'ok' if v >= 1.0 else 'warn' if v >= 0.85 else 'bad'
    check_cell(ws1, r, 4, status, f'{v:.1%}')

    # 信保系统完成率
    v = row_data['信保系统完成率']
    status = 'ok' if v >= 1.0 else 'warn' if v >= 0.85 else 'bad'
    check_cell(ws1, r, 5, status, f'{v:.1%}')

    # ACP完成率
    v = row_data['ACP季度完成率']
    status = 'ok' if v >= 1.0 else 'warn' if v >= 0.75 else 'bad'
    check_cell(ws1, r, 6, status, f'{v:.1%}')

    # 优爆品达成率
    v = row_data['优爆品达成率']
    status = 'ok' if v >= 1.0 else 'warn' if v >= 0.85 else 'bad'
    check_cell(ws1, r, 7, status, f'{v:.1%}')

    # 3W客户同比增减
    v = int(row_data['3W客户同比增减'])
    status = 'ok' if v >= 0 else 'warn' if v >= -2 else 'bad'
    check_cell(ws1, r, 8, status, f'{v:+d}家')

    # 提升维度数
    n = int(row_data['提升维度数'])
    c = ws1.cell(r, 9)
    c.value = n
    c.fill  = BG(C_RED2 if n >= 4 else C_ORG2 if n >= 2 else C_GRN2)
    c.font  = Font(name='Microsoft YaHei', size=14, bold=True,
                   color=C_RED if n >= 4 else C_ORANGE if n >= 2 else C_GREEN)
    c.alignment = AL('center'); c.border = BD()

    # ACP季度缺口
    gap_acp = int(row_data['ACP季度缺口'])
    c = ws1.cell(r, 10)
    c.value = gap_acp; c.number_format = '#,##0'
    c.fill  = BG(C_RED2 if gap_acp > 200000 else C_ORG2 if gap_acp > 0 else C_GRN2)
    c.font  = Font(name='Microsoft YaHei', size=10, bold=gap_acp > 0,
                   color=C_RED if gap_acp > 200000 else C_ORANGE if gap_acp > 0 else C_GREEN)
    c.alignment = AL('center'); c.border = BD()

    # 优爆品缺口
    gap_yb = int(row_data['优爆品缺口'])
    c = ws1.cell(r, 11)
    c.value = gap_yb; c.number_format = '#,##0'
    c.fill  = BG(C_RED2 if gap_yb > 500 else C_ORG2 if gap_yb > 0 else C_GRN2)
    c.font  = Font(name='Microsoft YaHei', size=10, bold=gap_yb > 0,
                   color=C_RED if gap_yb > 500 else C_ORANGE if gap_yb > 0 else C_GREEN)
    c.alignment = AL('center'); c.border = BD()

    # 综合判断
    weak_dims = []
    if row_data['信保激励完成率'] < 1.0: weak_dims.append('信保激励')
    if row_data['信保系统完成率'] < 1.0: weak_dims.append('信保系统')
    if row_data['ACP季度完成率']  < 1.0: weak_dims.append('ACP')
    if row_data['优爆品达成率']   < 1.0: weak_dims.append('优爆品')
    if row_data['3W客户同比增减'] < 0:   weak_dims.append('3W客户留存')
    summary = '需提升：' + ' / '.join(weak_dims) if weak_dims else '全面达标'
    c = ws1.cell(r, 12); c.value = summary
    c.fill = BG(C_RED2 if len(weak_dims) >= 4 else C_ORG2 if len(weak_dims) >= 2 else C_GRN2 if weak_dims else 'F0FFF4')
    c.font = Font(name='Microsoft YaHei', size=9, bold=True,
                  color=C_RED if len(weak_dims) >= 4 else C_ORANGE if len(weak_dims) >= 2 else C_GREEN)
    c.alignment = AL('left', wrap=True, indent=1); c.border = BD()
    r += 1

r += 2

# ── 雷达图数据区（用条形图代替雷达，兼容性更好） ──
r = section_title(ws1, r, 2, 12, '▌ 各维度完成率对比（信保激励 / ACP / 优爆品）')
r += 1

radar_df = df_sorted[['销售','信保激励完成率','信保系统完成率','ACP季度完成率','优爆品达成率']].copy()
radar_df.columns = ['销售','信保激励完成率','信保系统完成率','ACP季度完成率','优爆品达成率']
t_radar = build_table(ws1, data=radar_df, anchor=f'B{r}',
    theme='vibrant_marketing',
    column_formats={'信保激励完成率':'pct_1','信保系统完成率':'pct_1',
                    'ACP季度完成率':'pct_1','优爆品达成率':'pct_1'},
    auto_width=True, band_rows=True)
highlight_cells(ws1, t_radar, rules=[
    {'column':'信保激励完成率','when':'ge','value':1.0,'style':'green_fill'},
    {'column':'信保激励完成率','when':'lt','value':0.85,'style':'red_fill'},
    {'column':'信保系统完成率','when':'ge','value':1.0,'style':'green_fill'},
    {'column':'信保系统完成率','when':'lt','value':0.85,'style':'red_fill'},
    {'column':'ACP季度完成率','when':'ge','value':1.0,'style':'green_fill'},
    {'column':'ACP季度完成率','when':'lt','value':0.75,'style':'red_fill'},
    {'column':'优爆品达成率','when':'ge','value':1.0,'style':'green_fill'},
    {'column':'优爆品达成率','when':'lt','value':0.85,'style':'red_fill'},
])
add_color_scale(ws1, t_radar, columns=['信保激励完成率'], scale='red_white_green')
add_color_scale(ws1, t_radar, columns=['信保系统完成率'], scale='red_white_green')
add_color_scale(ws1, t_radar, columns=['ACP季度完成率'],  scale='red_white_green')
add_color_scale(ws1, t_radar, columns=['优爆品达成率'],   scale='red_white_green')

# 多系列条形图
build_chart(ws1, kind='clustered_bar',
    data_range=f"'提升维度评分矩阵'!B{t_radar['header_row']}:E{t_radar['data_rows'][1]}",
    series_orient='cols',
    title='各销售四维完成率对比',
    anchor=f'H{r}', size=(560, 340),
    theme='vibrant_marketing',
    legend='bottom',
    gridlines='horizontal_dashed',
    y_axis_min='zero',
    y_number_format='pct_1')

# ══════════════════════════════════════════
# SHEET 2: 各销售提升行动计划
# ══════════════════════════════════════════
ws2 = wb.create_sheet('各销售提升行动计划')
ws2.sheet_view.showGridLines = False
ws2.sheet_properties.tabColor = 'FA8C16'

for c in range(1, 10): ws2.column_dimensions[get_column_letter(c)].width = 22
ws2.column_dimensions['A'].width = 2
ws2.column_dimensions['B'].width = 14
ws2.column_dimensions['C'].width = 16
ws2.column_dimensions['D'].width = 28
ws2.column_dimensions['E'].width = 34
ws2.column_dimensions['F'].width = 20
ws2.column_dimensions['G'].width = 20
ws2.column_dimensions['H'].width = 16
ws2.column_dimensions['I'].width = 2

ws2.row_dimensions[1].height = 8
r2 = banner(ws2, 2, 2, 8,
    '各销售  提升维度  ×  行动建议  ×  重点客户',
    '基于FY27Q1数据  ·  按行动优先级排序  ·  数据截至2026-06-29',
    bg1='B33000', bg2=C_ORANGE)
r2 += 1

# 行动计划详情数据
ACTION_PLAN = {
    '狄鹏': {
        'priority': 'P0 🔴', 'priority_bg': C_RED,
        'weak': ['信保激励口径严重不足（29%）', 'ACP完成率48%缺口107万'],
        'actions': [
            '核查激励目标是否设置异常（激励目标是系统目标3.8倍）',
            '全力推动贴网成交，提升信保激励口径完成率',
            '对65个客户逐一筛选ACP开通潜力，季末集中转化',
        ],
        'kpi': '信保激励29% | 系统110% | ACP 48% | 优爆品84%',
    },
    '赵舒越': {
        'priority': 'P0 🔴', 'priority_bg': C_RED,
        'weak': ['ACP完成率75%（缺口30.4万）', '优爆品82%（缺787个）', '3W客户同比-4家'],
        'actions': [
            '信保GMV>3万的客户优先推进ACP开通，季末冲刺30万缺口',
            '加速优爆品审批提交，重点推动787个缺口完成认定',
            '排查3W客户流失名单，对已流失客户发起激活',
        ],
        'kpi': '信保激励187% | 系统100% | ACP 75% | 优爆品82%',
    },
    '李朝燕': {
        'priority': 'P1 🟠', 'priority_bg': 'FA8C16',
        'weak': ['信保系统完成率59%（最低）', '优爆品缺口1014个（最大）'],
        'actions': [
            '系统口径冲刺：推动高价值客户从激励口径转为系统贴网成交',
            '批量推进优爆品认定，101个服务客户是最大资源池',
            '开拓新客，3W客户22家偏低，季末推进2-3家新签',
        ],
        'kpi': '信保激励113% | 系统59% | ACP 275% | 优爆品82%',
    },
    '杨佳玮': {
        'priority': 'P1 🟠', 'priority_bg': 'FA8C16',
        'weak': ['信保系统完成率57%（团队最低）', 'ACP完成率72%', '优爆品82%'],
        'actions': [
            '系统口径优先：对高GMV客户推动贴网下单，提升系统完成率',
            'ACP转化：88个服务客户中筛选20+个高潜客户集中推进',
            '优爆品缺口703个，建立客户爆品认定排期，逐周跟进',
        ],
        'kpi': '信保激励105% | 系统57% | ACP 72% | 优爆品82%',
    },
    '燕磊': {
        'priority': 'P1 🟠', 'priority_bg': 'FA8C16',
        'weak': ['信保系统完成率84%', '优爆品达成率88%（缺口862个）', '3W客户同比-3家'],
        'actions': [
            '系统口径还差16%，聚焦3-5个中大型客户的贴网转化',
            '120个服务客户是团队最大盘，批量提报爆品认定材料',
            '排查3家流失3W客户，制定挽回方案',
        ],
        'kpi': '信保激励169% | 系统84% | ACP 105% | 优爆品88%',
    },
    '欧阳杰俊': {
        'priority': 'P1 🟠', 'priority_bg': 'FA8C16',
        'weak': ['信保系统完成率80%', '3W客户同比-1家', '单客户下滑最大（77.6万）'],
        'actions': [
            '优先挽救刘氏太阳能（下滑77.6万），1对1拜访核查原因',
            '系统口径还差20%，2-3个现有客户推动贴网成交即可完成',
            'ACP差6.6万完成季度目标，锁定1-2个高GMV客户收口',
        ],
        'kpi': '信保激励113% | 系统80% | ACP 96% | 优爆品100%',
    },
    '刘鑫': {
        'priority': 'P2 🟡', 'priority_bg': 'FADB14',
        'weak': ['信保系统完成率63%', 'ACP完成率89%（小缺口）'],
        'actions': [
            '系统口径冲刺：推动现有高GMV客户贴网，重点攻坚2-3家',
            'ACP小缺口，对完成率高的客户追加ACP服务包',
        ],
        'kpi': '信保激励117% | 系统63% | ACP 89% | 优爆品100%',
    },
    '杨婷婷': {
        'priority': 'P2 🟡', 'priority_bg': 'FADB14',
        'weak': ['信保系统完成率80%（轻微不足）', 'ACP完成率96%（近达标）'],
        'actions': [
            '系统口径再推1-2个客户贴网即可完成',
            'ACP差4%，聚焦1个高价值客户签约即可',
        ],
        'kpi': '信保激励113% | 系统80% | ACP 96% | 优爆品100%',
    },
    '高盛强': {
        'priority': 'P3 🟢', 'priority_bg': C_GREEN,
        'weak': ['优爆品94%（缺口374个，唯一弱项）'],
        'actions': [
            '季末推进374个优爆品认定审批，收口FY27Q1',
            '保持信保/ACP/3W客户现有优势，准备Q2目标规划',
        ],
        'kpi': '信保激励115% | 系统221% | ACP 127% | 优爆品94%',
    },
}

for sales in SALES_ORDER:
    info = ACTION_PLAN.get(sales)
    if not info: continue

    row_data = df[df['销售']==sales].iloc[0]

    # 销售标题行
    r2 += 1
    ws2.row_dimensions[r2].height = 28
    ws2.merge_cells(start_row=r2, start_column=2, end_row=r2, end_column=8)
    hc = ws2.cell(r2, 2)
    hc.value = f"  {sales}  [{info['priority']}]  —  {info['kpi']}"
    hc.fill = BG(info['priority_bg'])
    hc.font = Font(name='Microsoft YaHei', size=12, bold=True,
                   color='FFFFFF' if info['priority_bg'] not in ['FADB14'] else C_DEEP)
    hc.alignment = AL('left', indent=1)
    r2 += 1

    # 列表头
    ws2.row_dimensions[r2].height = 20
    for col, (hdr, bg_) in enumerate([
        ('需提升维度', 'EDF4FF'), ('行动建议', 'EDF4FF'), ('指标现状', 'EDF4FF'),
        ('ACP季度缺口', 'EDF4FF'), ('优爆品缺口', 'EDF4FF'), ('3W客户同比', 'EDF4FF')
    ], start=2):
        c = ws2.cell(r2, col)
        c.value = hdr; c.fill = BG(bg_)
        c.font = F(9, True, C_BLUE); c.alignment = AL('center'); c.border = BD()
    r2 += 1

    # 弱项维度
    max_lines = max(len(info['weak']), len(info['actions']))
    for i in range(max_lines):
        ws2.row_dimensions[r2].height = 22
        # 需提升维度
        c = ws2.cell(r2, 2)
        c.value = info['weak'][i] if i < len(info['weak']) else ''
        c.fill = BG(C_RED2 if c.value else C_BG)
        c.font = Font(name='Microsoft YaHei', size=9,
                      color=C_RED if c.value else C_GRAY, bold=bool(c.value))
        c.alignment = AL('left', wrap=True, indent=1); c.border = BD()

        # 行动建议
        c2 = ws2.cell(r2, 3)
        c2.value = info['actions'][i] if i < len(info['actions']) else ''
        c2.fill = BG('FFFBE6' if c2.value else C_BG)
        c2.font = Font(name='Microsoft YaHei', size=9, color='7C5000' if c2.value else C_GRAY)
        c2.alignment = AL('left', wrap=True, indent=1); c2.border = BD()

        if i == 0:
            # 指标现状（合并行）
            ws2.merge_cells(start_row=r2, start_column=4, end_row=r2+max_lines-1, end_column=4)
            c3 = ws2.cell(r2, 4)
            status_lines = [
                f"信保激励: {row_data['信保激励完成率']:.1%}",
                f"信保系统: {row_data['信保系统完成率']:.1%}",
                f"ACP季度:  {row_data['ACP季度完成率']:.1%}",
                f"优爆品:   {row_data['优爆品达成率']:.1%}",
                f"3W客户:   {int(row_data['3W客户同比增减']):+d}家",
                f"ACP渗透:  {row_data['ACP渗透率']:.2%}",
            ]
            c3.value = '\n'.join(status_lines)
            c3.fill = BG('F0F7FF'); c3.font = F(9, False, C_DEEP)
            c3.alignment = AL('left', wrap=True, indent=1); c3.border = BD()

            # ACP缺口
            ws2.merge_cells(start_row=r2, start_column=5, end_row=r2+max_lines-1, end_column=5)
            c4 = ws2.cell(r2, 5)
            gap_acp = int(row_data['ACP季度缺口'])
            c4.value = f"{gap_acp:,} 元" if gap_acp > 0 else "已达标 ✓"
            c4.fill = BG(C_RED2 if gap_acp > 200000 else C_ORG2 if gap_acp > 0 else C_GRN2)
            c4.font = Font(name='Microsoft YaHei', size=14, bold=True,
                           color=C_RED if gap_acp > 200000 else C_ORANGE if gap_acp > 0 else C_GREEN)
            c4.alignment = AL('center', wrap=True); c4.border = BD()

            # 优爆品缺口
            ws2.merge_cells(start_row=r2, start_column=6, end_row=r2+max_lines-1, end_column=6)
            c5 = ws2.cell(r2, 6)
            gap_yb = int(row_data['优爆品缺口'])
            c5.value = f"{gap_yb:,} 个" if gap_yb > 0 else "已达标 ✓"
            c5.fill = BG(C_RED2 if gap_yb > 500 else C_ORG2 if gap_yb > 0 else C_GRN2)
            c5.font = Font(name='Microsoft YaHei', size=14, bold=True,
                           color=C_RED if gap_yb > 500 else C_ORANGE if gap_yb > 0 else C_GREEN)
            c5.alignment = AL('center', wrap=True); c5.border = BD()

            # 3W客户同比
            ws2.merge_cells(start_row=r2, start_column=7, end_row=r2+max_lines-1, end_column=7)
            c6 = ws2.cell(r2, 7)
            delta = int(row_data['3W客户同比增减'])
            c6.value = f"{delta:+d} 家"
            c6.fill = BG(C_GRN2 if delta >= 0 else C_RED2)
            c6.font = Font(name='Microsoft YaHei', size=18, bold=True,
                           color=C_GREEN if delta >= 0 else C_RED)
            c6.alignment = AL('center'); c6.border = BD()

        else:
            for col in [4, 5, 6, 7]:
                c_ = ws2.cell(r2, col); c_.border = BD()

        r2 += 1

    r2 += 2   # 间距

# ══════════════════════════════════════════
# SHEET 3: 各销售重点客户清单
# ══════════════════════════════════════════
ws3 = wb.create_sheet('重点客户提升清单')
ws3.sheet_view.showGridLines = False
ws3.sheet_properties.tabColor = C_RED

for c in range(1, 11): ws3.column_dimensions[get_column_letter(c)].width = 18
ws3.column_dimensions['B'].width = 30   # 客户名称
ws3.column_dimensions['A'].width = 2

ws3.row_dimensions[1].height = 8
r3 = banner(ws3, 2, 2, 9,
    '各销售  重点客户提升清单  —  GMV下滑TOP10',
    '每位销售下滑金额最大的10个客户  ·  含分层、下滑额、下滑率  ·  建议优先挽救',
    bg1=C_RED, bg2='FF4D4F')
r3 += 1

ACCENT_MAP = {
    '高盛强':'0050B3','燕磊':'B34000','杨婷婷':'006D36',
    '欧阳杰俊':'531DAB','赵舒越':'00718C','刘鑫':'7B3800',
    '李朝燕':'876800','杨佳玮':'135200','狄鹏':'780650',
}

for sales in SALES_ORDER:
    sub = cust_down[cust_down['拍档销售']==sales].copy()
    if sub.empty: continue

    top10 = sub.nlargest(10, 'GMV下滑额').copy()

    # 挽救优先级标签
    def rescue_pri(row):
        if row['GMV下滑率'] < -0.8 or row['GMV下滑额'] > 200000:
            return '🔴 立即'
        if row['GMV下滑率'] < -0.5 or row['GMV下滑额'] > 80000:
            return '🟠 本周'
        return '🟡 本月'
    top10['挽救优先级'] = top10.apply(rescue_pri, axis=1)

    top10 = top10[['公司名称','本季度GMV','同比季度GMV','GMV下滑额','GMV下滑率',
                   '本季度分层','同比季度分层','挽救优先级']].rename(columns={
        '公司名称':'客户名称','本季度GMV':'本季GMV（元）','同比季度GMV':'同比GMV（元）',
        'GMV下滑额':'下滑金额（元）','GMV下滑率':'下滑率',
        '本季度分层':'本季分层','同比季度分层':'同比分层'
    })
    top10.insert(0, '排名', range(1, len(top10)+1))

    # 销售标题
    r3 += 1
    accent = ACCENT_MAP.get(sales, C_BLUE)
    row_data = df[df['销售']==sales].iloc[0]
    total_down = int(sub['GMV下滑额'].sum())
    down_cnt   = len(sub)
    ws3.row_dimensions[r3].height = 28
    ws3.merge_cells(start_row=r3, start_column=2, end_row=r3, end_column=9)
    hc = ws3.cell(r3, 2)
    hc.value = (f"  {sales}  [{row_data['行动优先级']}]"
                f"  ·  下滑客户 {down_cnt} 家"
                f"  ·  下滑总额 {total_down:,} 元"
                f"  ·  ACP缺口 {int(row_data['ACP季度缺口']):,} 元"
                f"  ·  优爆品缺 {int(row_data['优爆品缺口'])} 个")
    hc.fill = BG(accent)
    hc.font = Font(name='Microsoft YaHei', size=11, bold=True, color='FFFFFF')
    hc.alignment = AL('left', indent=1)
    r3 += 1

    t3 = build_table(ws3, data=top10, anchor=f'A{r3}',
        theme='vibrant_marketing',
        column_formats={'本季GMV（元）':'simple_int','同比GMV（元）':'simple_int',
                        '下滑金额（元）':'simple_int','下滑率':'pct_1'},
        auto_width=True, band_rows=True)
    highlight_cells(ws3, t3, rules=[
        {'column':'下滑率','when':'lt','value':-0.8,'style':'red_fill'},
        {'column':'下滑率','when':'between','value':(-0.8,-0.5),'style':'amber_fill'},
        {'column':'挽救优先级','when':'eq','value':'🔴 立即','style':'red_fill'},
        {'column':'挽救优先级','when':'eq','value':'🟠 本周','style':'amber_fill'},
        {'column':'排名','when':'le','value':3,'style':'red_text'},
    ])
    add_data_bars(ws3, t3, columns=['下滑金额（元）'], color='rose')
    r3 = t3['data_rows'][1] + 3

# Sheet顺序
for i, name in enumerate(['提升维度评分矩阵','各销售提升行动计划','重点客户提升清单']):
    wb.move_sheet(name, offset=-(len(wb.sheetnames)-i))

wb.save(OUT)
print('DONE:', OUT)
