"""
拍档业务仪表盘 Sheet1(团队业绩仪表盘) + Sheet3(客户GMV下滑分析) → 长图
修复：用序号索引 Worksheets(i) 替代字符串，避免中文 sheet 名 COM 报错
"""
import os, time, sys, struct
import win32com.client as win32
import win32clipboard
from PIL import Image, ImageDraw, ImageFont

XLSX = r'C:\Users\zhaos\.accio\accounts\1747555973_470001\agents\DID-F456DA-15F456DAU1781073-7441-58F963\project\拍档业务仪表盘.xlsx'
OUT  = r'C:\Users\zhaos\.accio\accounts\1747555973_470001\agents\DID-F456DA-15F456DAU1781073-7441-58F963\project\拍档业务仪表盘_长图.png'

# 目标 sheet 名（用于日志显示）
TARGET_NAMES = ['团队业绩仪表盘', '客户GMV下滑分析']
BG_COLOR = (10, 22, 40)


def clipboard_to_pil():
    """从剪贴板读取 DIB 图片 → PIL RGB"""
    win32clipboard.OpenClipboard()
    try:
        formats = []
        fmt = win32clipboard.EnumClipboardFormats(0)
        while fmt:
            formats.append(fmt)
            fmt = win32clipboard.EnumClipboardFormats(fmt)

        for cf in [8, 17]:   # CF_DIB, CF_DIBV5
            if cf not in formats:
                continue
            try:
                data = win32clipboard.GetClipboardData(cf)
                hdr_size, w, h = struct.unpack_from('<Iii', data)[:3]
                bpp = struct.unpack_from('<H', data, 14)[0]
                raw = data[hdr_size:]
                flip = 1 if h < 0 else -1
                h = abs(h)
                if bpp == 32:
                    img = Image.frombuffer('RGBA', (w, h), raw, 'raw', 'BGRA', 0, flip)
                else:
                    img = Image.frombuffer('RGB',  (w, h), raw, 'raw', 'BGR',  0, flip)
                return img.convert('RGB')
            except Exception as e:
                print(f"  DIB cf={cf} err: {e}")
    finally:
        try:
            win32clipboard.EmptyClipboard()
        except Exception:
            pass
        win32clipboard.CloseClipboard()

    raise RuntimeError(f"剪贴板解码失败，可用格式: {formats}")


def get_sheet_max_extent(ws):
    """返回 sheet 使用范围（含图表对象）的最大行列"""
    used  = ws.UsedRange
    max_r = used.Row + used.Rows.Count - 1
    max_c = used.Column + used.Columns.Count - 1
    try:
        for i in range(1, ws.ChartObjects().Count + 1):
            co    = ws.ChartObjects(i)
            bot   = co.TopLeftCell.Row    + int(co.Height / ws.Rows(1).Height)    + 2
            right = co.TopLeftCell.Column + int(co.Width  / ws.Columns(1).Width)  + 2
            max_r = max(max_r, bot)
            max_c = max(max_c, right)
    except Exception:
        pass
    return max_r, max_c


def screenshot_sheet(ws, name):
    """截取 ws 完整区域（含图表）→ PIL Image"""
    ws.Activate()
    time.sleep(0.6)

    max_r, max_c = get_sheet_max_extent(ws)
    print(f"  [{name}] 截图范围: 行1~{max_r}, 列1~{max_c}")

    rng = ws.Range(ws.Cells(1, 1), ws.Cells(max_r, max_c))
    rng.CopyPicture(Appearance=1, Format=2)   # xlScreen=1, xlBitmap=2
    time.sleep(1.0)

    return clipboard_to_pil()


# ── 主流程 ────────────────────────────────────────────────────
print("启动 Excel COM...")
excel = win32.gencache.EnsureDispatch('Excel.Application')
excel.Visible        = True
excel.DisplayAlerts  = False
excel.ScreenUpdating = True

print(f"打开文件: {XLSX}")
wb = excel.Workbooks.Open(XLSX)
time.sleep(2.5)

# 用序号枚举所有 sheet，找到目标
sheet_map = {}   # name → index (1-based)
for i in range(1, wb.Worksheets.Count + 1):
    n = wb.Worksheets(i).Name
    print(f"  Sheet {i}: {n}")
    sheet_map[n] = i

images = []
for target in TARGET_NAMES:
    idx = sheet_map.get(target)
    if idx is None:
        print(f"  ⚠️  未找到 Sheet: {target}，跳过")
        continue
    ws = wb.Worksheets(idx)
    try:
        img = screenshot_sheet(ws, target)
        print(f"  ✅ 截图成功: {img.size}")
        images.append((target, img))
    except Exception as e:
        print(f"  ❌ 截图失败: {e}")

wb.Close(False)
excel.Quit()
print("\nExcel 已关闭")

if not images:
    print("没有截到任何图片，退出")
    sys.exit(1)

# ── 拼接长图 ──────────────────────────────────────────────────
print("\n开始拼接...")
max_w = max(img.width for _, img in images)
SEP_H = 32

parts = []
for i, (name, img) in enumerate(images):
    # 宽度对齐
    if img.width < max_w:
        bg = Image.new('RGB', (max_w, img.height), BG_COLOR)
        bg.paste(img, (0, 0))
        img = bg

    if i > 0:
        sep = Image.new('RGB', (max_w, SEP_H), BG_COLOR)
        d = ImageDraw.Draw(sep)
        d.line([(40, SEP_H // 2), (max_w - 40, SEP_H // 2)], fill=(30, 58, 90), width=2)
        parts.append(sep)

    parts.append(img)

total_h = sum(p.height for p in parts)

# 底部水印
FOOTER_H = 44
footer = Image.new('RGB', (max_w, FOOTER_H), (12, 25, 50))
d = ImageDraw.Draw(footer)
txt = '阿里巴巴一拍档  东莞市橙辉供应链管理有限公司  FY27Q1 业务数据仪表盘  数据管理大师  2026-06-29'
try:
    fnt = ImageFont.truetype('C:/Windows/Fonts/msyh.ttc', 15)
except Exception:
    fnt = ImageFont.load_default()
bb = d.textbbox((0, 0), txt, font=fnt)
tw = bb[2] - bb[0]
d.text(((max_w - tw) // 2, (FOOTER_H - 18) // 2), txt, fill=(70, 120, 170), font=fnt)

canvas = Image.new('RGB', (max_w, total_h + FOOTER_H), BG_COLOR)
y = 0
for p in parts:
    canvas.paste(p, (0, y))
    y += p.height
canvas.paste(footer, (0, total_h))

# 超过 4096px 宽则等比压缩
MAX_W = 4096
if canvas.width > MAX_W:
    r = MAX_W / canvas.width
    canvas = canvas.resize((MAX_W, int(canvas.height * r)), Image.LANCZOS)

canvas.save(OUT, 'PNG', optimize=True)
sz_mb = os.path.getsize(OUT) / 1024 / 1024
print(f"\n✅ 长图保存完成: {OUT}")
print(f"   尺寸: {canvas.width} × {canvas.height} px  |  大小: {sz_mb:.1f} MB")
