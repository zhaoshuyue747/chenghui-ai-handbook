"""
alibaba-quality-to-hit Excel 报告生成器 v1.2.0
品牌：小蜂学掌 · https://www.xfxz123.com/

Usage:
    python gen_excel.py <input_json> [<output_xlsx>]

若不指定 output_xlsx，自动解析输出目录：
  - 工作空间 output/ 优先
  - 无工作空间则桌面创建「优品爆品分析」文件夹
"""
import json
import os
import sys
from pathlib import Path
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.formatting.rule import ColorScaleRule

# ── 品牌常量（内部使用，不在对话框输出） ────────────────────────────────────
_BRAND_NAME     = "小蜂学掌"
_BRAND_URL      = "www.xfxz123.com"
_BRAND_URL_FULL = "https://www.xfxz123.com/"

# ── colour palette ─────────────────────────────────────────────────────────
C_HEADER_BG  = "1F3864"
C_HEADER_FG  = "FFFFFF"
C_TITLE_BG   = "2E75B6"
C_TITLE_FG   = "FFFFFF"
C_BAND1      = "FFFFFF"
C_BAND2      = "DCE6F1"
C_COVER_BG   = "0F2C4D"   # 封面深色底
C_COVER_GOLD = "F2A633"   # 封面金色装饰

FONT_CJK = "Microsoft YaHei"


# ── 路径解析 ────────────────────────────────────────────────────────────────
def _resolve_output_dir() -> Path:
    """工作空间 output/ 优先；无则在桌面创建「优品爆品分析」文件夹。"""
    skill_root = Path(__file__).resolve().parent.parent
    ws_out = skill_root / "output"
    try:
        if skill_root.exists() and os.access(str(skill_root), os.W_OK):
            ws_out.mkdir(parents=True, exist_ok=True)
            return ws_out
    except Exception:
        pass
    if sys.platform.startswith("win"):
        home = Path(os.environ.get("USERPROFILE", str(Path.home())))
        desktop = home / "Desktop"
        if not desktop.exists():
            desktop = home / "桌面"
    else:
        desktop = Path.home() / "Desktop"
    out = desktop / "优品爆品分析"
    out.mkdir(parents=True, exist_ok=True)
    return out


# ── helpers ────────────────────────────────────────────────────────────────
def fill(hex_color):
    return PatternFill("solid", fgColor=hex_color)

def thin_border():
    s = Side(style="thin", color="BFBFBF")
    return Border(left=s, right=s, top=s, bottom=s)

def center_align(wrap=False):
    return Alignment(horizontal="center", vertical="center", wrap_text=wrap)

def left_align(wrap=True):
    return Alignment(horizontal="left", vertical="center", wrap_text=wrap)

def apply_header(ws, row, cols, labels, bg=C_HEADER_BG, fg=C_HEADER_FG):
    for col, label in zip(cols, labels):
        c = ws.cell(row=row, column=col, value=label)
        c.font = Font(name=FONT_CJK, bold=True, size=10, color=fg)
        c.fill = fill(bg)
        c.alignment = center_align(wrap=True)
        c.border = thin_border()

def apply_cell(ws, row, col, value, bg=None, bold=False, align="left",
               color="000000", number_format=None, hyperlink=None):
    c = ws.cell(row=row, column=col, value=value)
    c.font = Font(name=FONT_CJK, bold=bold, size=10, color=color)
    if bg:
        c.fill = fill(bg)
    c.alignment = center_align() if align == "center" else left_align()
    c.border = thin_border()
    if number_format:
        c.number_format = number_format
    if hyperlink:
        c.hyperlink = hyperlink
        c.font = Font(name=FONT_CJK, size=10, color="0563C1", underline="single")
    return c

def set_col_width(ws, col, width):
    ws.column_dimensions[get_column_letter(col)].width = width

def write_title_row(ws, row, text, ncols, bg=C_TITLE_BG):
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=ncols)
    c = ws.cell(row=row, column=1, value=text)
    c.font = Font(name=FONT_CJK, bold=True, size=12, color=C_TITLE_FG)
    c.fill = fill(bg)
    c.alignment = center_align()
    ws.row_dimensions[row].height = 28


# ── 品牌页眉页脚注入 ────────────────────────────────────────────────────────
def _inject_brand_hf(ws):
    """为工作表注入品牌页眉页脚（打印时显示）。"""
    ws.oddHeader.left.text  = f"&\"{FONT_CJK}\"&10{_BRAND_NAME}"
    ws.oddHeader.right.text = f"&10{_BRAND_URL}"
    ws.oddHeader.left.size  = 9
    ws.oddHeader.right.size = 9
    ws.oddFooter.left.text  = f"&9{_BRAND_NAME}  ·  {_BRAND_URL_FULL}"
    ws.oddFooter.right.text = "&9第 &P 页 / 共 &N 页"
    ws.print_options.horizontalCentered = True


# ── 封面 Sheet ──────────────────────────────────────────────────────────────
def _build_cover(wb, crawl_date, threshold, total_quality,
                 candidates_abc, total_hits, total_warnings):
    ws = wb.active
    ws.title = "封面"
    ws.sheet_view.showGridLines = False

    ncols = 6
    last  = get_column_letter(ncols)

    def _merge_row(row, val, bg, font, height=30):
        ws.merge_cells(f"A{row}:{last}{row}")
        c = ws.cell(row=row, column=1, value=val)
        c.fill = fill(bg)
        c.font = font
        c.alignment = center_align()
        ws.row_dimensions[row].height = height

    # 顶部空白
    ws.row_dimensions[1].height = 10

    # 品牌 LOGO 行
    _merge_row(2,
               f"  {_BRAND_NAME}  ·  {_BRAND_URL_FULL}",
               C_COVER_BG,
               Font(name=FONT_CJK, size=12, bold=True, color="F2A633"),
               height=30)

    # 金色装饰条
    ws.merge_cells(f"A3:{last}3")
    ws.cell(row=3, column=1).fill = fill(C_COVER_GOLD)
    ws.row_dimensions[3].height = 5

    # 主标题（跨多行）
    ws.merge_cells(f"A4:{last}6")
    c_title = ws.cell(row=4, column=1, value="优品→爆品转化监控报告")
    c_title.fill = fill(C_COVER_BG)
    c_title.font = Font(name=FONT_CJK, size=24, bold=True, color="FFFFFF")
    c_title.alignment = center_align()
    for r in range(4, 7):
        ws.row_dimensions[r].height = 28

    # 副标题
    _merge_row(7,
               f"数据日期：{crawl_date}  |  爆品临界值：近90天支付买家 ≥ {threshold}",
               C_COVER_BG,
               Font(name=FONT_CJK, size=12, color="87CEEB"),
               height=24)

    # 空行
    ws.merge_cells(f"A8:{last}8")
    ws.cell(row=8, column=1).fill = fill(C_COVER_BG)
    ws.row_dimensions[8].height = 12

    # 数据摘要区
    summary_items = [
        ("优品总数",      total_quality,    "总抓取量"),
        ("打爆候选(A/B/C)",candidates_abc,  "本次可冲刺"),
        ("现有爆品数",    total_hits,        "需持续维护"),
        ("预警产品数",    total_warnings,    "需立即行动"),
    ]
    label_font = Font(name=FONT_CJK, size=11, bold=True, color="F2A633")
    val_font   = Font(name=FONT_CJK, size=20, bold=True, color="FFFFFF")
    sub_font   = Font(name=FONT_CJK, size=9,  bold=False, color="87CEEB")

    for i, (label, val, sub) in enumerate(summary_items):
        r_label = 9 + i * 3
        r_val   = r_label + 1
        r_sub   = r_val + 1
        ws.merge_cells(f"A{r_label}:{last}{r_label}")
        lc = ws.cell(row=r_label, column=1, value=label)
        lc.fill = fill(C_COVER_BG); lc.font = label_font; lc.alignment = center_align()
        ws.row_dimensions[r_label].height = 18

        ws.merge_cells(f"A{r_val}:{last}{r_val}")
        vc = ws.cell(row=r_val, column=1, value=val)
        vc.fill = fill(C_COVER_BG); vc.font = val_font; vc.alignment = center_align()
        ws.row_dimensions[r_val].height = 34

        ws.merge_cells(f"A{r_sub}:{last}{r_sub}")
        sc = ws.cell(row=r_sub, column=1, value=sub)
        sc.fill = fill(C_COVER_BG); sc.font = sub_font; sc.alignment = center_align()
        ws.row_dimensions[r_sub].height = 14

    # Powered by 底部落款
    bot = 9 + len(summary_items) * 3 + 1
    ws.merge_cells(f"A{bot}:{last}{bot}")
    bc = ws.cell(row=bot, column=1,
                 value=f"Powered by {_BRAND_NAME}  ·  {_BRAND_URL_FULL}")
    bc.fill = fill(C_COVER_GOLD)
    bc.font = Font(name=FONT_CJK, size=10, bold=True, color="0F2C4D")
    bc.alignment = center_align()
    ws.row_dimensions[bot].height = 24

    for col in range(1, ncols + 1):
        ws.column_dimensions[get_column_letter(col)].width = 20

    _inject_brand_hf(ws)
    return ws


# ── classification logic ───────────────────────────────────────────────────
def get_diff(p, threshold):
    try:
        return threshold - int(p.get("paid_buyers_90d") or 0)
    except Exception:
        return 999

def get_priority(p, threshold):
    imp    = int(p.get("impressions_30d") or 0)
    diff   = get_diff(p, threshold)
    buyers = int(p.get("paid_buyers_90d") or 0)
    if buyers >= threshold:
        return "✅ 已达爆品"
    if imp >= 200 and diff == 1:
        return "🥇 A级"
    if imp >= 200 and 2 <= diff <= 3:
        return "🥈 B级"
    if imp < 200 and diff <= 2:
        return "🥉 C级"
    if imp >= 200 and diff >= 4:
        return "📋 培育期"
    return "⬇️ 暂缓"

def get_action(p, threshold):
    diff   = get_diff(p, threshold)
    imp    = int(p.get("impressions_30d") or 0)
    tm     = int(p.get("tm_inquiry_90d") or 0)
    buyers = int(p.get("paid_buyers_90d") or 0)
    if buyers >= threshold:
        return "维持现有策略，保持P4P稳定投放"
    actions = []
    if diff == 1:
        actions.append(f"差{diff}单冲爆品！立即加大P4P投放抢首位流量")
    elif diff <= 3:
        actions.append(f"差{diff}单，重点投广+跟进询盘转化")
    else:
        actions.append(f"差{diff}单，先拉升曝光再谈转化")
    if imp < 200:
        actions.append(f"曝光仅{imp}，必须先投广拉量")
    if tm >= 3:
        actions.append(f"TM+询盘{tm}个，优先跟进已有商机")
    return "；".join(actions)

def get_safety(p, threshold):
    buyers = int(p.get("paid_buyers_90d") or 0)
    diff   = buyers - threshold
    if diff > 1:
        return "🟢 安全"
    elif diff == 1:
        return "🟡 警告"
    elif diff == 0:
        return "🔴 临界"
    else:
        return "❌ 低于标准"

def get_maintain_advice(p, threshold):
    buyers  = int(p.get("paid_buyers_90d") or 0)
    surplus = buyers - threshold
    if surplus == 0:
        return "⚠️临界！立即联系已有询盘买家复购，目标14天内新增1-2单；P4P持续投放保曝光>300"
    elif surplus == 1:
        return "黄色预警，联系历史买家维系关系，保持P4P稳定投放，每周检查买家数变化"
    else:
        return "保持现有P4P投放策略，定期回访客户，维持优质服务响应"


# ── main builder ───────────────────────────────────────────────────────────
def build(input_json, output_xlsx):
    with open(input_json, encoding="utf-8") as f:
        data = json.load(f)

    quality      = data.get("quality_products_all_pages", [])
    hit_products = data.get("hit_products", [])
    crawl_date   = data.get("crawl_date", "")

    threshold_obj = data.get("hit_threshold", {})
    threshold = int(
        threshold_obj.get("standard_value") or
        threshold_obj.get("standard_paid_buyers_90d") or
        5
    )

    priority_order = ["🥇 A级", "🥈 B级", "🥉 C级", "📋 培育期", "✅ 已达爆品", "⬇️ 暂缓"]
    sorted_quality = sorted(quality, key=lambda p: (
        priority_order.index(get_priority(p, threshold))
        if get_priority(p, threshold) in priority_order else 99,
        get_diff(p, threshold)
    ))

    # 统计数据（供封面使用）
    candidates_abc = sum(
        1 for p in quality
        if get_priority(p, threshold) in ("🥇 A级", "🥈 B级", "🥉 C级")
    )
    total_warnings = sum(1 for p in quality if p.get("warning"))

    wb = Workbook()
    wb._named_styles["Normal"].font = Font(name=FONT_CJK, size=10)

    # ── 封面 Sheet ────────────────────────────────────────────────────────
    _build_cover(wb, crawl_date, threshold,
                 len(quality), candidates_abc, len(hit_products), total_warnings)

    # ── Sheet 1: 优品打爆候选 ─────────────────────────────────────────────
    ws1 = wb.create_sheet("优品打爆候选")
    ws1.freeze_panes = "C3"

    COLS1   = ["优先级", "产品ID", "产品标题", "曝光(30d)", "访客(30d)",
               "TM+询盘(90d)", "支付买家(90d)", "爆品差额", "竞争力标签",
               "打爆建议", "产品链接"]
    WIDTHS1 = [12, 16, 45, 11, 10, 13, 13, 10, 14, 40, 14]

    write_title_row(ws1, 1,
        f"店铺优品打爆候选分析  |  爆品临界值：近90天支付买家≥{threshold}  |  数据日期：{crawl_date}",
        len(COLS1))
    apply_header(ws1, 2, range(1, len(COLS1)+1), COLS1)
    ws1.row_dimensions[2].height = 36

    for i, col_w in enumerate(WIDTHS1, 1):
        set_col_width(ws1, i, col_w)

    row = 3
    for idx, p in enumerate(sorted_quality):
        bg       = C_BAND1 if idx % 2 == 0 else C_BAND2
        priority = get_priority(p, threshold)
        diff     = get_diff(p, threshold)
        buyers   = int(p.get("paid_buyers_90d") or 0)

        if priority == "🥇 A级":
            bg = "FFE5E5"
        elif priority == "🥈 B级":
            bg = "FFF3E0"
        elif priority == "🥉 C级":
            bg = "FFFDE0"
        elif priority == "✅ 已达爆品":
            bg = "E8F5E9"

        vals   = [priority, p.get("id", ""), p.get("title", ""),
                  int(p.get("impressions_30d") or 0), int(p.get("visitors_30d") or 0),
                  int(p.get("tm_inquiry_90d") or 0), buyers,
                  diff if buyers < threshold else 0,
                  "、".join(p.get("competitiveness_labels", [])) or "-",
                  get_action(p, threshold), "点击查看"]
        fmts   = [None,"@",None,"#,##0","#,##0","#,##0","#,##0","#,##0",None,None,None]
        aligns = ["center","center","left","center","center","center","center",
                  "center","center","left","center"]

        for col_i, (val, fmt, aln) in enumerate(zip(vals, fmts, aligns), 1):
            if col_i == 11:
                apply_cell(ws1, row, col_i, val, bg=bg, align=aln,
                           hyperlink=p.get("url", ""))
            else:
                apply_cell(ws1, row, col_i, val, bg=bg, align=aln, number_format=fmt)

        ws1.row_dimensions[row].height = 48
        row += 1

    if row > 3:
        ws1.conditional_formatting.add(
            f"H3:H{row-1}",
            ColorScaleRule(
                start_type="num", start_value=0, start_color="63BE7B",
                mid_type="num",   mid_value=3,   mid_color="FFEB84",
                end_type="num",   end_value=5,   end_color="F8696B",
            )
        )

    _inject_brand_hf(ws1)

    # ── Sheet 2: 爆品监控 ─────────────────────────────────────────────────
    ws2 = wb.create_sheet("爆品监控")
    ws2.freeze_panes = "C3"

    COLS2   = ["安全状态", "产品ID", "产品标题", "曝光(30d)", "访客(30d)",
               "TM+询盘(90d)", "支付买家(90d)", "爆品标准", "安全余量",
               "竞争力标签", "维持建议", "产品链接"]
    WIDTHS2 = [10, 16, 45, 11, 10, 13, 13, 10, 10, 14, 42, 14]

    write_title_row(ws2, 1,
        f"爆品监控  |  爆品临界值：近90天支付买家≥{threshold}  |  数据日期：{crawl_date}",
        len(COLS2))
    apply_header(ws2, 2, range(1, len(COLS2)+1), COLS2)
    ws2.row_dimensions[2].height = 36

    for i, col_w in enumerate(WIDTHS2, 1):
        set_col_width(ws2, i, col_w)

    sorted_hits = sorted(hit_products, key=lambda p: int(p.get("paid_buyers_90d") or 0))

    for idx, p in enumerate(sorted_hits):
        buyers  = int(p.get("paid_buyers_90d") or 0)
        surplus = buyers - threshold
        safety  = get_safety(p, threshold)

        if surplus == 0:
            bg = "FFD7D7"
        elif surplus == 1:
            bg = "FFF9C4"
        else:
            bg = C_BAND1 if idx % 2 == 0 else C_BAND2

        vals   = [safety, p.get("id", ""), p.get("title", ""),
                  int(p.get("impressions_30d") or 0), int(p.get("visitors_30d") or 0),
                  int(p.get("tm_inquiry_90d") or 0), buyers, threshold, surplus,
                  "、".join(p.get("competitiveness_labels", [])) or "-",
                  get_maintain_advice(p, threshold), "点击查看"]
        fmts   = [None,"@",None,"#,##0","#,##0","#,##0","#,##0","#,##0","#,##0",None,None,None]
        aligns = ["center","center","left","center","center","center","center",
                  "center","center","center","left","center"]

        for col_i, (val, fmt, aln) in enumerate(zip(vals, fmts, aligns), 1):
            if col_i == 12:
                apply_cell(ws2, idx+3, col_i, val, bg=bg, align=aln,
                           hyperlink=p.get("url", ""))
            else:
                apply_cell(ws2, idx+3, col_i, val, bg=bg, align=aln, number_format=fmt)

        ws2.row_dimensions[idx+3].height = 48

    _inject_brand_hf(ws2)

    # ── Sheet 3: 全量优品数据 ─────────────────────────────────────────────
    ws3 = wb.create_sheet("全量优品数据")
    ws3.freeze_panes = "C3"

    COLS3   = ["产品ID", "产品标题", "产品类型", "状态", "曝光(30d)", "访客(30d)",
               "TM+询盘(90d)", "支付买家(90d)", "爆品差额", "优先级",
               "竞争力标签", "产品链接"]
    WIDTHS3 = [16, 48, 10, 8, 11, 10, 13, 13, 10, 12, 14, 14]

    write_title_row(ws3, 1,
        f"全量优品数据（{len(quality)}条）  |  数据日期：{crawl_date}",
        len(COLS3))
    apply_header(ws3, 2, range(1, len(COLS3)+1), COLS3, bg="243F60")
    ws3.row_dimensions[2].height = 36

    for i, col_w in enumerate(WIDTHS3, 1):
        set_col_width(ws3, i, col_w)

    for idx, p in enumerate(sorted_quality):
        bg     = C_BAND1 if idx % 2 == 0 else C_BAND2
        buyers = int(p.get("paid_buyers_90d") or 0)
        diff   = get_diff(p, threshold)

        vals   = [p.get("id", ""), p.get("title", ""), p.get("type", ""),
                  p.get("status_label", ""),
                  int(p.get("impressions_30d") or 0), int(p.get("visitors_30d") or 0),
                  int(p.get("tm_inquiry_90d") or 0), buyers,
                  diff if buyers < threshold else 0,
                  get_priority(p, threshold),
                  "、".join(p.get("competitiveness_labels", [])) or "-",
                  "点击查看"]
        fmts   = ["@",None,None,None,"#,##0","#,##0","#,##0","#,##0","#,##0",None,None,None]
        aligns = ["center","left","center","center","center","center","center",
                  "center","center","center","center","center"]

        for col_i, (val, fmt, aln) in enumerate(zip(vals, fmts, aligns), 1):
            if col_i == 12:
                apply_cell(ws3, idx+3, col_i, val, bg=bg, align=aln,
                           hyperlink=p.get("url", ""))
            else:
                apply_cell(ws3, idx+3, col_i, val, bg=bg, align=aln, number_format=fmt)

        ws3.row_dimensions[idx+3].height = 40

    if quality:
        ws3.conditional_formatting.add(
            f"I3:I{len(quality)+2}",
            ColorScaleRule(
                start_type="num", start_value=0, start_color="63BE7B",
                mid_type="num",   mid_value=3,   mid_color="FFEB84",
                end_type="num",   end_value=5,   end_color="F8696B",
            )
        )

    _inject_brand_hf(ws3)

    wb.save(output_xlsx)
    return output_xlsx


# ── CLI entry ──────────────────────────────────────────────────────────────
def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)

    input_json = sys.argv[1]
    if not os.path.exists(input_json):
        print(f"ERROR: input json not found: {input_json}")
        sys.exit(2)

    if len(sys.argv) >= 3:
        output_xlsx = sys.argv[2]
    else:
        with open(input_json, encoding="utf-8") as f:
            crawl_date = json.load(f).get("crawl_date", "today")
        out_dir     = _resolve_output_dir()
        output_xlsx = str(out_dir / f"{_BRAND_NAME}_优品爆品分析_{crawl_date}.xlsx")

    out = build(input_json, output_xlsx)
    print(f"\n文件已保存至：{os.path.abspath(out)}\n")


if __name__ == "__main__":
    main()
