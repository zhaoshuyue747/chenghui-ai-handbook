# alibaba-quality-to-hit

阿里巴巴国际站优品→爆品转化监控工具 (v1.1.0)

## 功能

- 🎯 自动抓取商品运营工作台「店铺优品 + 爆品」全量数据
- 📊 按交易品/商机品两条路径筛选打爆候选 (A/B/C 五级)
- 💡 输出每个候选的具体打爆建议（含数字目标）
- 🚨 识别即将掉出爆品序列的预警品 + 维持建议
- 📈 一键生成 3-Sheet 工业级 Excel 报告（自动保存桌面）
- ⏰ 支持每周二 09:00 定时执行

## 快速使用

### 触发语
```
按 alibaba-quality-to-hit 执行本周优品→爆品分析
```

### 手动调用 Excel 生成器
```bash
python scripts/gen_excel.py <input_json> [<output_xlsx>]
```

不指定输出路径时，默认保存到桌面：`优品爆品分析_<crawl_date>.xlsx`

## Excel 输出结构

| Sheet | 内容 |
|---|---|
| **优品打爆候选** | 按 A/B/C 级排序，含打爆建议、差额色阶 |
| **爆品监控** | 按危险度排序，安全余量配色，维持建议 |
| **全量优品数据** | 所有优品原始数据 + 优先级分类 |

## 文件结构

```
alibaba-quality-to-hit/
├── SKILL.md                # Skill 完整规范（核心）
├── README.md               # 本文件
├── scripts/
│   └── gen_excel.py        # Excel 生成器
└── examples/
    ├── sample_data.json    # 示例原始数据（21条优品+3个爆品）
    ├── sample_report.md    # 示例 Markdown 报告
    └── sample_excel.xlsx   # 示例 Excel 输出
```

## 安装到 Accio Work

将整个文件夹复制到：
```
~/.accio/accounts/<account_id>/agents/<agent_id>/agent-core/skills/
```

或全账户共享：
```
~/.accio/accounts/<account_id>/skills/
```

## 依赖

- Python ≥ 3.8
- openpyxl ≥ 3.1
- 浏览器 sub-agent (Accio Work 内置)

## 详细规范

请阅读 [SKILL.md](SKILL.md) 了解：
- 完整字段定义与公式
- 5 级优先级判定规则
- 8 条 Sanity 自检清单
- 定时任务配置示例
